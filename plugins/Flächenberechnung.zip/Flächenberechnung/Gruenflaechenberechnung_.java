import ij.*;
import ij.plugin.filter.PlugInFilter;
//import ij.plugin.frame.ColorThresholder;
import ij.plugin.frame.*;
import ij.plugin.*;
import ij.process.*;

import java.awt.*;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import ij.*;
import ij.io.*;
import ij.gui.*;
import java.io.File;

import ij.plugin.*;
import ij.*;
import ij.io.*;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.*;

import java.util.Arrays;
import java.util.Collections;
import ij.io.Opener;

import java.util.ArrayList;
import java.util.List;

import ij.measure.Calibration;
import ij.macro.Interpreter;

import java.text.DecimalFormat;
import java.lang.Math;

import java.util.Date;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;

import java.awt.*;
import javax.swing.*;

import ij.gui.NonBlockingGenericDialog;

/*
Algemeine Infos:

Bilder auf jeden Fall unter 4.000px * 3.000px = 12.000.000px
Könnte auch sein dass es noch deutlich kleiner sein muss!

Funktioniert: 3.834.560px

*/

public class Gruenflaechenberechnung_ extends ImagePlus implements PlugIn {
	
ImagePlus imp;
ImagePlus imp_a;
protected byte[] pixels;
String path;

File[] files;

private int type;

String StartFileName;
String StartFileNameSmall;
String StartFileDirectory;
String[] coords_array;
String[] good_coords_array;
String[] clean_coords_array;

String[] exportImages;
String[] exportCalc;

String color_string_value;
Integer[] color_int_values;
Boolean[] color_bool_values;


static float alpha = HarrisCornerDetector.DEFAULT_ALPHA;
static int threshold = HarrisCornerDetector.DEFAULT_THRESHOLD;
static int nmax = 0; //points to show
static File dir;

//ColorThresholderExtended
String method = "DEFAULT";
int minHue = 20;
int maxHue = 100;
int minSat = 0;
int maxSat = 255;
int minBri = 0;
int maxBri = 170;
int mode = 0;
int colorSpace = 0;
int method_int = 0;
boolean bandPassH = true;
boolean bandPassS = true;
boolean bandPassB = true;
boolean darkBackground = false;

byte[] PixelMask;

boolean finished = false;
boolean problem = true;

double scale_inCM = 0;
double scale_PxCM = 0;
double scale_CMPx = 0;

//Einzelnes Viereck Batch-----------
Roi batch_rois;
String batchName = "dlg.canceled";
String summary_batch = "plot|name|dateandtime|qcm|percentage";
String summary_batch_name;
ImageStack imstack;
String[] time_array;

//Oscar I-----------

int Oscar_I = 0;
/*Maske_alt
int[] Oscar_I_x = {32,72,116,156,221,261,305,345,410,450,494,534,599,639,683,723,809,849,893,933,998,1038,1082,1122,1187,1227,1271,1311,1376,1416,1460,1500};
int[] Oscar_I_y = {850,705,631,486,412,267,193,48};
*/
//Maske Neu
int[] Oscar_I_x = {115,230,354,468,652,766,890,1004,1188,1302,1426,1540,1724,1838,1963,2077,2320,2434,2559,2673,2857,2971,3095,3209,3393,3507,3631,3745,3929,4043,4168,4282};
int[] Oscar_I_y = {2582,2170,1961,1549,1339,927,718,306};

//AKWHA I-----------

int AKWHA_I = 1;

String[] AKWHA_I_lengths = {"5.91;6.21;5.28", "5.72;5.16;5.53", "11.26;11.9;6.61", "6.34;6.79;6.82", "6.66;6.82;7.22", "10.65;10.82;7.65"};
//a;b;c
int AKWHA_I_I_II = 0;
int AKWHA_I_III_IV = 1;

int point_counter = 0;
int points_up_counter = 0;
int points_down_counter = 0;

double[] distances_left = {6,12,13.5,19.5,25.5,27,33,39,40.5,46.5,52.5};
double[] distances_right = {6,12,13.5,19.5,25.5,27,33,39,40.5,46.5,52.5,55.5};
double[] distances_y = {15,30,45,60};

Point[] points_up = new Point[24];
Point[] points_down= new Point[24];

//AKWHA II-----------

int AKWHA_II = 2;

String[] AKWHA_II_lengths = {"7.71;7.36;3", "7.3;7.19;3.57", "7.52;7.24;4.02", "5.65;6.29;5.14", "9.98;8.19;6.82", "9.67;7.63;7.65"};

double[] distances_left_II = {1.5,7.6,13.7,15.2,21.3,27.4,28.9,35,41.1,42.6,48.7,54.8};
double[] distances_right_II = {6.1,12.2,13.7,19.8,25.9,27.4,33.5,39.6,41.1,47.2,53.3};

int[] xpoints = new int[12];
int[] ypoints = new int[12];

int[] xpoints_flaechen = new int[120];
int[] ypoints_flaechen = new int[120];

	public void run(String arg) {
		
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String selection = showChoice();
		System.out.println("Auswahl: " + selection);
		
		if(selection.equals("Einzelnes Viereck Batch")){
			startevBatch();
		}
		if(selection.equals("Oscar I")){
			startOscar();
		}
		if(selection.equals("VORAN")){
			startVORAN();
		}
		if(selection.equals("AKHWA I")){
			startReferencePoints(AKWHA_I);
		}
		if(selection.equals("AKHWA II")){
			startReferencePoints(AKWHA_II);
		}
		if(selection.equals("OSCAR")){
			//startOSCAR();
		}
		if(selection.equals("Einzelnes Viereck")){
			startEinzelnViereck();
		}
		if(selection.equals("Mehrere Vierecke")){
			startMehrereVierecke();
		}
		if(selection.equals("")){
			//if (!showInfo("Fehler", "Fehler beim Erstellen des Export-Verzeichnisses")) return;
		}
		
	}
	
	public void startevBatch(){
		files = openFiles();
			
			Opener opener = new Opener();
			if(files != null){
				
				boolean isCreated = false;
				
				File dir = new File(path+"/Export");
				if(!dir.exists()){
					isCreated = dir.mkdir();
				}
				
				if(dir.exists() || isCreated){
					finished = false;
					
					int files_amount = files.length;
					int maximum = files_amount + files_amount/50;
					
					//Progress bar
					final JFrame f;
					final JProgressBar b;
				    
				    // create a frame
			        f = new JFrame("Progress...");
			        JPanel p = new JPanel();
			        b = new JProgressBar();
			        b.setMinimum(0);
			        b.setMaximum(maximum);
			        b.setValue(0);
			        b.setStringPainted(true);
			        p.add(b);
			        f.add(p);
			        f.setSize(300, 100);
			        
			        int step = 1;
			        
			        time_array = new String[files.length];
			        
					for (int i = 0; i < files.length; i++) {
						ImagePlus img = opener.openImage(path, files[i].getName());
						
						if (img!=null) {
							imp = img;
							//imp.show();
							//showInfo("Info", datetime);
							
							StartFileDirectory = getDirectory(imp);
							StartFileName = getFileName(imp);
							
							String datetime = getFileDateandTime(imp);
							time_array[i] = datetime;
							
							String StartFilePathName = StartFileDirectory + StartFileName;
							
							ImagePlus imp2 = new ImagePlus();
							imp2.setImage(imp);
							//imp.close();
							//imp2.show();
							
							if(i == 0) {
								
								imp2.show();
								
								//For real reference
								getScale(imp2);
								
								IJ.setTool("rectangle");
								
								InputDialog inputrectangle = new InputDialog("Input", "Please draw Rectangle\nRectangle and Points are movable", "Rectangle", imp2);
								inputrectangle.show();
								
								Point[] points;
								Rectangle rectangle;
								
								batch_rois = imp2.getRoi();
								
								rectangle = batch_rois.getBounds();
								System.out.println("x,y: " + rectangle.x + "," + rectangle.y);
								
								while(batchName.equals("dlg.canceled")) {
									batchName = enterName();
								}
								
								imp2.setRoi(batch_rois);
								ImagePlus temp_crop = imp2.crop();
								ImageProcessor iptemp = temp_crop.getProcessor();
								int width = iptemp.getWidth();
								int height = iptemp.getHeight();
								
								imstack = new ImageStack(width, height);
									
							} 
							
							imp2.close();

							f.setVisible(true);
							b.setValue(i*step);
							
							Opener opener_new = new Opener();
							ImagePlus impToCrop = opener_new.openImage(StartFilePathName);
							
							impToCrop.setRoi(batch_rois);
							
							ImagePlus imp3 = impToCrop.crop();
							
							String name = StartFileDirectory + "/Export/" + StartFileName + "_" + batchName + "_" + String.valueOf(i) + "_" + "original";
							
							String export_name = name + ".tif";
							
							ImageProcessor ip3 = imp3.getProcessor();
							
							imstack.addSlice(StartFileName, ip3);
							
							//IJ.saveAs(imp3, "tiff", name); //Hier am Ende nur den Stack speichern?
							
							if(i == files.length-1){
								finished = true;
								//Das muss noch wo anders hin
								problem = false;
							}
							/*if(finished && !problem){
								//saveData(summary_batch, summary_batch_name);
								showInfo("Info", "Exportierung und Berechnung erfolgreich abgeschlossen");
							}*/
						}
					}
					f.setVisible(false);
					String stackexportname = StartFileDirectory + "/Export/" + batchName + "_original_stack";
					
					ImagePlus StackImage = new ImagePlus("Batchname", imstack);
					IJ.saveAs(StackImage, "tiff", stackexportname);
					
					//After all Rectangles aquired and stacked, start thresholding
					
					loadimagesevBatchStack(imstack, StackImage);
					
				} else {
					//Not created, message!
					if (!showInfo("Fehler", "Fehler beim Erstellen des Export-Verzeichnisses")) return;
				}
			} else {
				//No files selected, message!
				if (!showInfo("Fehler", "Keine Dateien ausgew\u00e4hlt.")) return;
			}
	}
	
	public void startOscar(){
		files = openFiles();
			
			Opener opener = new Opener();
			if(files != null){
				
				boolean isCreated = false;
				
				File dir = new File(path+"/Export");
				if(!dir.exists()){
					isCreated = dir.mkdir();
				}
				
				if(dir.exists() || isCreated){
					finished = false;
					for (int i=0; i<files.length; i++) {
						ImagePlus img = opener.openImage(path, files[i].getName());
						if (img!=null)
							imp = img;
							imp.show();
							loadimagesOscar(i);
							if(i == files.length-1){
								finished = true;
							}
							if(finished && !problem){
								showInfo("Info", "Exportierung und Berechnung erfolgreich abgeschlossen");
							}
					}
				} else {
					//Not created, message!
					if (!showInfo("Fehler", "Fehler beim Erstellen des Export-Verzeichnisses")) return;
				}
			} else {
				//No files selected, message!
				if (!showInfo("Fehler", "Keine Dateien ausgew\u00e4hlt.")) return;
			}
	}
	
	public void startVORAN(){
		files = openFiles();
			
			Opener opener = new Opener();
			if(files != null){
				
				boolean isCreated = false;
				
				File dir = new File(path+"/Export");
				if(!dir.exists()){
					isCreated = dir.mkdir();
				}
				
				if(dir.exists() || isCreated){
					finished = false;
					for (int i=0; i<files.length; i++) {
						ImagePlus img = opener.openImage(path, files[i].getName());
						if (img!=null)
							imp = img;
							imp.show();
							loadimages(i);
							if(i == files.length-1){
								finished = true;
							}
							if(finished && !problem){
								showInfo("Info", "Exportierung und Berechnung erfolgreich abgeschlossen");
							}
					}
				} else {
					//Not created, message!
					if (!showInfo("Fehler", "Fehler beim Erstellen des Export-Verzeichnisses")) return;
				}
			} else {
				//No files selected, message!
				if (!showInfo("Fehler", "Keine Dateien ausgew\u00e4hlt.")) return;
			}
	}
	
	public void startEinzelnViereck(){
		files = openFiles();
			
			Opener opener = new Opener();
			if(files != null){
				
				boolean isCreated = false;
				
				File dir = new File(path+"/Export");
				if(!dir.exists()){
					isCreated = dir.mkdir();
				}
				
				if(dir.exists() || isCreated){
					finished = false;
					for (int i=0; i<files.length; i++) {
						ImagePlus img = opener.openImage(path, files[i].getName());
						if (img!=null)
							imp = img;
							imp.show();
							loadimagesEinzeln(i);
							if(i == files.length-1){
								finished = true;
							}
							if(finished && !problem){
								showInfo("Info", "Exportierung und Berechnung erfolgreich abgeschlossen");
							}
					}
				} else {
					//Not created, message!
					if (!showInfo("Fehler", "Fehler beim Erstellen des Export-Verzeichnisses")) return;
				}
			} else {
				//No files selected, message!
				if (!showInfo("Fehler", "Keine Dateien ausgew\u00e4hlt.")) return;
			}
	}
	
	public void startMehrereVierecke(){
		files = openFiles();
			
			Opener opener = new Opener();
			if(files != null){
				
				boolean isCreated = false;
				
				File dir = new File(path+"/Export");
				if(!dir.exists()){
					isCreated = dir.mkdir();
				}
				
				if(dir.exists() || isCreated){
					finished = false;
					for (int i=0; i<files.length; i++) {
						ImagePlus img = opener.openImage(path, files[i].getName());
						if (img!=null)
							imp = img;
							imp.show();
							loadimagesMehrereVierecke(i);
							if(i == files.length-1){
								finished = true;
							}
							if(finished && !problem){
								showInfo("Info", "Exportierung und Berechnung erfolgreich abgeschlossen");
							}
					}
				} else {
					//Not created, message!
					if (!showInfo("Fehler", "Fehler beim Erstellen des Export-Verzeichnisses")) return;
				}
			} else {
				//No files selected, message!
				if (!showInfo("Fehler", "Keine Dateien ausgew\u00e4hlt.")) return;
			}
	}
	
	public void startReferencePoints(int project){
		files = openFiles();
			
			Opener opener = new Opener();
			if(files != null){
				
				boolean isCreated = false;
				
				File dir = new File(path+"/Export");
				if(!dir.exists()){
					isCreated = dir.mkdir();
				}
				
				if(dir.exists() || isCreated){
					finished = false;
					for (int i=0; i<files.length; i++) {
						ImagePlus img = opener.openImage(path, files[i].getName());
						if (img!=null)
							imp = img;
							imp.show();
							loadimagesReferencePoints(i, project);
							if(i == files.length-1){
								finished = true;
							}
							if(finished && !problem){
								showInfo("Info", "Exportierung und Berechnung erfolgreich abgeschlossen");
							}
					}
				} else {
					//Not created, message!
					if (!showInfo("Fehler", "Fehler beim Erstellen des Export-Verzeichnisses")) return;
				}
			} else {
				//No files selected, message!
				if (!showInfo("Fehler", "Keine Dateien ausgew\u00e4hlt.")) return;
			}
	}
	
	File[] openFiles() {
		
		File[] files_open;
		
		JFileChooser fc = null;
		try {
			fc = new JFileChooser();
		}
		catch (Throwable e) {
			IJ.error("This plugin requires Java 2 or Swing."); return null;
		}
		fc.setMultiSelectionEnabled(true);
		
		if (dir==null) {
			String sdir = OpenDialog.getDefaultDirectory();
			if (sdir!=null)
				dir = new File(sdir);
		}
		if (dir!=null)
			fc.setCurrentDirectory(dir);
		
		int returnVal = fc.showOpenDialog(IJ.getInstance());
		
		if (returnVal!=JFileChooser.APPROVE_OPTION)
			return null;
		
		files_open = fc.getSelectedFiles();
		
		if (files_open.length==0) { // getSelectedFiles does not work on some JVMs
			files_open = new File[1];
			files_open[0] = fc.getSelectedFile();
		}
		path = fc.getCurrentDirectory().getPath()+Prefs.getFileSeparator();
		
		return files_open;
	}
	
	public void loadimagesOscar(int CountImages){
		imp = IJ.getImage();
		ImageProcessor originalip = imp.getProcessor();
		
		StartFileDirectory = getDirectory(imp);
		StartFileName = getFileName(imp);
		
		String splitString[] = StartFileName.split("_");
		String StartFileMask = splitString[0];
		
		StartFileNameSmall = StartFileName.substring(6);
		
		String CropPath = StartFileDirectory + StartFileNameSmall;
		
		//Starte Funktion Ausschneiden und Thresholding
		
		loadimagesFixPoints(CountImages, Oscar_I);
		
	}
	
	public void loadimages(int CountImages){
		imp = IJ.getImage();
		ImageProcessor originalip = imp.getProcessor();
		
		StartFileDirectory = getDirectory(imp);
		StartFileName = getFileName(imp);
		
		String splitString[] = StartFileName.split("_");
		String StartFileMask = splitString[0];
		
		StartFileNameSmall = StartFileName.substring(6);
		
		String CropPath = StartFileDirectory + StartFileNameSmall;
				
		ImagePlus imp2 = new ImagePlus();
		imp2.setImage(imp);
		//imp.close();
		imp2.show();
		
		ImageConverter ic = new ImageConverter(imp2);
		ic.convertToGray8();
		
		ImageProcessor newip = imp2.getProcessor();
		
		//if (!showDialog()) return;
		
		HarrisCornerDetector hcd = new HarrisCornerDetector(newip,alpha,threshold);
		hcd.findCorners();
		//ImageProcessor result = hcd.showCornerPoints(newip);
		ImageProcessor result = hcd.showCornerPoints(newip);
		
		String coords = hcd.getCoordinatesString();
		//String coords = "";
		coords_array = hcd.getCoordinatesArray();
		
		for(int i = 0; i < coords_array.length; i++) {
			System.out.println(coords_array[i]);
		}
		
		ImagePlus win = new ImagePlus("Corners from " + imp.getTitle(),result);
		win.show();
		//imp2.close(); //Hier Originalbild anschauen
		//win.close(); //Hier die erkannten Eckpunkte anschauen
		
		//saveData(coords, "coordsnew.txt");
		//exportCropImages(CropPath, CountImages, StartFileMask);
	}
	
	public void loadimagesevBatchStack(ImageStack imstack, ImagePlus impstack){
		
		String filename = "";
		
		String export_pixelvalues = "";
		String filename_pixelvalues = "";
		
		impstack.show();
		
		Integer[] input_int = new Integer[9];
		input_int[0] = minHue;
		input_int[1] = maxHue;
		input_int[2] = minSat;
		input_int[3] = maxSat;
		input_int[4] = minBri;
		input_int[5] = maxBri;
		input_int[6] = mode;
		input_int[7] = colorSpace;
		input_int[8] = method_int;
		
		Boolean[] input_bool = new Boolean[4];
		input_bool[0] = bandPassH;
		input_bool[1] = bandPassS;
		input_bool[2] = bandPassB;
		input_bool[3] = darkBackground;
		
		ColorThresholderExtended thresher = new ColorThresholderExtended(); //Color Threshold Fenster öffnen
		//thresher.setStringValue(method);
		thresher.setIntValues(input_int);
		thresher.setBoolValues(input_bool);
		
		thresher.updateAfterSetting(impstack);
		
		boolean stack_action = thresher.getStackAction();
		boolean stackdialog = false;
		
		while (!stackdialog) {
			stack_action = thresher.getStackAction();
			stackdialog = dialolgStackAction("Input", "Please first adjust Threshold\nThen use Stack and on completion click ok here", stack_action, thresher);
		}
		
		/*InputDialog inputcolorthresher = new InputDialog("Input", "Please first adjust Threshold\nThen use Stack and on completion click ok here", "Threshold", impstack);
		inputcolorthresher.show();*/
		
		//color_string_value = thresher.getStringValue();
		color_int_values = thresher.getIntValues();
		color_bool_values = thresher.getBoolValues();
		
		//method = color_string_value;
		method = "DEFAULT";
		minHue = color_int_values[0];
		maxHue = color_int_values[1];
		minSat = color_int_values[2];
		maxSat = color_int_values[3];
		minBri = color_int_values[4];
		maxBri = color_int_values[5];
		mode = color_int_values[6];
		colorSpace = color_int_values[7];
		method_int = color_int_values[8];
		bandPassH = color_bool_values[0];
		bandPassS = color_bool_values[1];
		bandPassB = color_bool_values[2];
		darkBackground = color_bool_values[3];
			
		System.out.println("Active Windows: " + WindowManager.getWindowCount());
		
		String added = color_int_values[0] + ", " + color_int_values[1] + ", " + color_bool_values[0] + ", " + color_int_values[2] + ", " + color_int_values[3] + ", " + color_bool_values[1] + ", " + color_int_values[4] + ", " + color_int_values[5] + ", " + color_bool_values[2] + ", " + color_int_values[8] + ", " + color_int_values[6] + ", " + color_int_values[7] + ", " + color_bool_values[3];
		
		System.out.println("Values: " + added);
		
		//Hier bei Bedarf stattdessen Alterselection einf�gen
		
		int numSlices = impstack.getStackSize();
		
		for (int l = 1; l <= numSlices; l++) {
			
			impstack.setSlice(l);
			StartFileName = imstack.getSliceLabel(l);
			
			String datetime = time_array[l-1];
			
			byte[] maske = readFileBinary(impstack, String.valueOf(l) + "_Slice.bin");
			
			thresher.drawBinaryStack(maske, impstack, l);
			
			ImageProcessor ip = imstack.getProcessor(l);
			
			ImageStatistics stats = ImageStatistics.getStatistics(ip, ImageStatistics.AREA_FRACTION, null);
			
			int width = ip.getWidth();
			int height = ip.getHeight();
			
			double real_area = 0;
			
			if(scale_CMPx != 0) {
				real_area = (width * scale_CMPx) * (height * scale_CMPx);
			}
			
			double aFraction = stats.areaFraction;
			double greenFraction = 100-aFraction;
			//double area = (aFraction * 36)/100;
			
			DecimalFormat df = new DecimalFormat("#.#####");
			String aFraction_df = df.format(greenFraction); 
			
			double measure_counter = 0;
			
			for(int i = 0; i < maske.length; i++){
				if (maske[i]!=0){
					//fill
					measure_counter++;
				}
			}
			//Prozent Abdeckung der thresholded Pixel
			double PixelFraction = (measure_counter * 100) / maske.length;
			
			double RealFraction = (real_area * PixelFraction) / 100;
			
			System.out.println("maske.length: " + maske.length + "\nMeasure_Counter: " + measure_counter + "\nPixelFraction: " + PixelFraction + "\nArea: " + real_area);
			
			String pixel_aFraction_df = df.format(PixelFraction); 
			String real_Fraction_df = df.format(RealFraction);
			
			String real_Fraction_complete = real_Fraction_df + " cm�";
			
			if(RealFraction == 0) {
				real_Fraction_complete = "Konnte nicht ausgerechnet werden.";
			}
			
			filename = StartFileName + "_" + batchName + "_" + String.valueOf(l) + "_Fl\u00e4chenexport" + ".txt";		
			
			summary_batch = summary_batch + "\n" + batchName + "|" + StartFileName + "|" + datetime + "|" + real_Fraction_df + "|" + pixel_aFraction_df;
			
			String[] rgb_values = extractPixelValues(impstack, maske);
			
			StringBuilder sb = new StringBuilder();
	
			for(int i = 0; i < rgb_values.length; i++){
				sb.append(rgb_values[i]);
			}
			export_pixelvalues = sb.toString();
			filename_pixelvalues = StartFileName + "_" + batchName + "_" + String.valueOf(l) + "_Einzelpixel_Export" + ".txt";
			saveData(export_pixelvalues, filename_pixelvalues);
			
		}
		
		thresher.close();
		summary_batch_name = batchName + "_summary.txt";
		saveData(summary_batch, summary_batch_name);
		
		String stackexportname = StartFileDirectory + "/Export/" + batchName + "_binary_stack";
		IJ.saveAs(impstack, "tiff", stackexportname);	
		impstack.close();
		
	}
	
	byte[] readFileBinary(ImagePlus imp, String filename) {
		String currentPath = getDirectory(imp);
		String savePath = currentPath;
		
		File file = new File(savePath + "/" + filename);
		
		FileInputStream fileInputStream = null;
		byte[] bFile = new byte[(int) file.length()];
		try {
			//convert file into array of bytes
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bFile);
			fileInputStream.close();
			for (int i = 0; i < bFile.length; i++) {
				System.out.print((char) bFile[i]);
			}
		} catch (Exception e) {
         e.printStackTrace();
		}
		
		file.delete();
		
		return bFile;
	}
	
	public void loadimagesEinzeln(int CountImages){
		imp = IJ.getImage();
		ImageProcessor originalip = imp.getProcessor();
		
		StartFileDirectory = getDirectory(imp);
		StartFileName = getFileName(imp);
		
		String StartFilePathName = StartFileDirectory + StartFileName;
				
		ImagePlus imp2 = new ImagePlus();
		imp2.setImage(imp);
		imp.close();
		imp2.show();
		
		//For real reference
		//getScale(imp2);
		
		IJ.setTool("rectangle");
		
		InputDialog inputrectangle = new InputDialog("Input", "Please draw Rectangle\nRectangle and Points are movable", "Rectangle", imp2);
		inputrectangle.show();
		
		//IJ.run(imp2, "Color Threshold...", "sigma"); ------WICHTIG COLOR THRESHOLD
		Roi rois;
		Point[] points;
		Rectangle rectangle;
		
		rois = imp2.getRoi();
		
		rectangle = rois.getBounds();
		System.out.println("x,y: " + rectangle.x + "," + rectangle.y);
		
		/*for(int i = 0; i < points.length; i++){
			int x = points[i].x;
			int y = points[i].y;
			System.out.println(String.valueOf(i) + ": " + String.valueOf(x) + "," + String.valueOf(y));
		}*/
			
		
		imp2.close();
		//saveData(coords, "coordsnew2.txt");
		exportCropImagesEinzelViereck(StartFilePathName, StartFileName, rois, "1");
	}
	
	public void loadimagesMehrereVierecke(int CountImages){
		imp = IJ.getImage();
		ImageProcessor originalip = imp.getProcessor();
		
		StartFileDirectory = getDirectory(imp);
		StartFileName = getFileName(imp);
		
		String StartFilePathName = StartFileDirectory + StartFileName;
		
		int amount = 0;
		
		while(amount == 0) {
			amount = showMehrereVierecke();
		}
		
		if(amount > 0) {
			System.out.println("Amount: " + amount);
			
			getScale(imp);
			
			for(int i = 0; i < amount; i++) {
				ImagePlus imp2 = new ImagePlus();
				imp2.setImage(imp);
				//imp.close();
				imp2.show();
				
				IJ.setTool("rectangle");
				
				InputDialog inputrectangle = new InputDialog("Input", "Please draw Rectangle\nRectangle and Points are movable", "Rectangle", imp2);
				inputrectangle.show();
				
				Roi rois;
				Point[] points;
				Rectangle rectangle;
				
				rois = imp2.getRoi();
				
				rectangle = rois.getBounds();
				System.out.println("x,y: " + rectangle.x + "," + rectangle.y);
				
				imp2.close();
				
				//saveData(coords, "coordsnew2.txt");
				exportCropImagesEinzelViereck(StartFilePathName, StartFileName, rois, String.valueOf(i+1));
			}
			
			imp.close();
			
		} else {
			if(amount == -1) {
				showInfo("Info", "Eingabe abgebrochen");
				problem = true;
				imp.close();
			}
		}
	}
	
public void loadimagesFixPoints(int CountImages, int project){
		
		imp = IJ.getImage();
		ImageProcessor originalip = imp.getProcessor();
		
		StartFileDirectory = getDirectory(imp);
		StartFileName = getFileName(imp);
		
		String StartFilePathName = StartFileDirectory + StartFileName;
		String export = String.valueOf(CountImages);
		String summary = "plot|qcm|percentage";
		String name_export_summary = "";
				
		ImagePlus imp2 = new ImagePlus();
		imp2.setImage(imp);
		imp.close();
		imp2.show();
		
		int height = imp.getHeight();
		int width = imp.getWidth();
				
		if(project == Oscar_I) {
			
			Point[] points;
			Roi rois;
			
			ImagePlus imp_export = imp2;
			ImagePlus[] imp_crop = new ImagePlus[64];
			
			int crop_counter = 0;
			
			//Schleife mit der L�nge 16
			//Unterschleife mit der L�nge 4
			
			for(int i = 0; i < 16; i++) {
				for(int k = 0; k < 4; k++) {
					//System.out.println("Punkt:" + i + "," + xpoints_flaechen[i] + "," + ypoints_flaechen[i]);
					
					imp_crop[i] = new ImagePlus();
					imp_crop[i].setImage(imp2);					
							
					imp_crop[i].show();
					
					int roi_x1 = Oscar_I_x[i*2];
					int roi_x2 = Oscar_I_x[i*2+1];
					int roi_y1 = Oscar_I_y[k*2+1];;
					int roi_y2 = Oscar_I_y[k*2];
					
					int a = roi_x2 - roi_x1;
					int b = roi_y2 - roi_y1;
					
					Roi roi_imp = new Roi(roi_x1, roi_y1, a, b);
					
					imp_crop[i].setRoi(roi_imp);
					
					IJ.run(imp_crop[i], "Crop", "");
					IJ.run("Maximize", "");
					
					export = String.valueOf(crop_counter+1);
					
					String name = StartFileDirectory + "/Export/" + StartFileName + "_" + export;
					
					String export_name = name + ".tif";
					
					IJ.saveAs(imp_crop[i], "tiff", name);
					
					int crop_height = imp_crop[i].getHeight();
					int crop_width = imp_crop[i].getWidth();
					
					ColorThresholderExtended thresher = new ColorThresholderExtended(); //Color Threshold Fenster �ffnen
					
					Integer[] input_int = new Integer[9];
					input_int[0] = minHue;
					input_int[1] = maxHue;
					input_int[2] = minSat;
					input_int[3] = maxSat;
					input_int[4] = minBri;
					input_int[5] = maxBri;
					input_int[6] = mode;
					input_int[7] = colorSpace;
					input_int[8] = method_int;
					
					Boolean[] input_bool = new Boolean[4];
					input_bool[0] = bandPassH;
					input_bool[1] = bandPassS;
					input_bool[2] = bandPassB;
					input_bool[3] = darkBackground;
					
					//thresher.setStringValue(method);
					thresher.setIntValues(input_int);
					thresher.setBoolValues(input_bool);
					
					InputDialog inputcolorthresher = new InputDialog("Input", "Please adjust Threshold", "Threshold", imp_crop[i]);
					inputcolorthresher.show();
					
					//color_string_value = thresher.getStringValue();
					color_int_values = thresher.getIntValues();
					color_bool_values = thresher.getBoolValues();
					
					//method = color_string_value;
					method = "DEFAULT";
					minHue = color_int_values[0];
					maxHue = color_int_values[1];
					minSat = color_int_values[2];
					maxSat = color_int_values[3];
					minBri = color_int_values[4];
					maxBri = color_int_values[5];
					mode = color_int_values[6];
					colorSpace = color_int_values[7];
					method_int = color_int_values[8];
					bandPassH = color_bool_values[0];
					bandPassS = color_bool_values[1];
					bandPassB = color_bool_values[2];
					darkBackground = color_bool_values[3];
					
					String added = color_int_values[0] + ", " + color_int_values[1] + ", " + color_bool_values[0] + ", " + color_int_values[2] + ", " + color_int_values[3] + ", " + color_bool_values[1] + ", " + color_int_values[4] + ", " + color_int_values[5] + ", " + color_bool_values[2] + ", " + color_int_values[8] + ", " + color_int_values[6] + ", " + color_int_values[7] + ", " + color_bool_values[3];
					
					System.out.println("Values: " + added);							
					
					PixelMask = thresher.getdrawfillMask();
					
					thresher.drawBinary(PixelMask, imp_crop[i]);
					
					thresher.close();
					
					String name_export = StartFileDirectory + "/Export/" + StartFileName + "_" + export + "_binary.tif";
					
					
					IJ.saveAs(imp_crop[i], "tiff", name_export);
					//imp_crop[i].close();
					//crop_counter++;
					
					//Fl�che berechnen
												
					double real_area_complete = 300000;
					
					DecimalFormat df = new DecimalFormat("#.###");
					double measure_counter = 0;
					
					for(int l = 0; l < PixelMask.length; l++){
						if (PixelMask[l]!=0){
							//fill
							measure_counter++;
						}
					}
					
					double RealFraction = (100 * measure_counter) / PixelMask.length;
					
					double real_area = real_area_complete/100*RealFraction;
					
					System.out.println("PixelMask.length: " + PixelMask.length + "\nMeasure_Counter: " + measure_counter + "\nRealFraction: " + RealFraction + "\nArea: " + real_area);
					
					String pixel_aFraction_df = df.format(RealFraction); 
					String real_Fraction_df = df.format(real_area);
					
					String real_Fraction_complete = real_Fraction_df + " cm�";
					
					if(RealFraction == 0) {
						real_Fraction_complete = "Konnte nicht ausgerechnet werden.";
					}
					
					String text = "Prozentuale Fl\u00e4che: " + pixel_aFraction_df + " %" + "\nReale Fl\u00e4che: " + real_Fraction_complete;
					String filename = StartFileName + "_" + export + "_Fl\u00e4chenexport" + ".txt";
					
					summary = summary + "\n" + export + "|" + real_Fraction_df + "|" + pixel_aFraction_df;
					name_export_summary = StartFileName + "_summary.txt";
					
					/*Opener opener_topixel = new Opener();
					ImagePlus imp_a_pixelvalues = opener_topixel.openImage(export_name);
					
					if(imp_a_pixelvalues != null){
						String[] rgb_values = extractPixelValues(imp_a_pixelvalues, PixelMask);
						
						StringBuilder sb_pixel = new StringBuilder();
				
						for(int l = 0; l < rgb_values.length; l++){
							sb_pixel.append(rgb_values[l]);
						}
						export_pixelvalues = sb_pixel.toString();
						filename_pixelvalues = StartFileName + "_" + export + "_Einzelpixel_Export" + ".txt";
					}*/
					
					imp_crop[i].close();
					crop_counter++;
					
					//Hier Text-Dateien speichern
					
					saveData(text, filename);
					//saveData(export_pixelvalues, filename_pixelvalues);
					
					
				}
			}
			
			//imp2.setRoi(new PointRoi(pointsX, pointsY, pointsY.length));
			//imp2.setRoi(new PointRoi(xpoints_flaechen, ypoints_flaechen, ypoints_flaechen.length));
			//IJ.run("Scale to Fit", "");
			
			//imp_export.show();
			
			saveData(summary, name_export_summary);
			
			imp2.close();
			problem = false;
		}
	}
	
	public void loadimagesReferencePoints(int CountImages, int project){
		
		imp = IJ.getImage();
		ImageProcessor originalip = imp.getProcessor();
		
		StartFileDirectory = getDirectory(imp);
		StartFileName = getFileName(imp);
		
		String StartFilePathName = StartFileDirectory + StartFileName;
				
		ImagePlus imp2 = new ImagePlus();
		imp2.setImage(imp);
		imp.close();
		imp2.show();
		
		int height = imp.getHeight();
		int width = imp.getWidth();
		
		IJ.setTool("multipoint");
		
		if(project == AKWHA_I) {
			
			InputDialog inputreferencepoints = new InputDialog("Input", "Please enter Reference-Points for AKWHA I Project\nPoints are movable\nDelete with ALT + Click on Point", "AKWHA", imp2); //�berpr�fen ob 12 Punkte eingegeben wurden! �ber anderen Input �ber "Points"
			inputreferencepoints.show();
			
			Point[] points;
			Roi rois;
			
			rois = imp2.getRoi();
			
			if( rois instanceof PointRoi ){
				points = rois.getContainedPoints();
				//System.out.println("Length: " + points.length);
				
				StringBuilder sb = new StringBuilder();
				
				for(int i = 0; i < points.length; i++){
					for(int k = 0; k < points.length; k++) {
						
						int x_0 = points[i].x;
						int y_0 = points[i].y;
						
						int x_1 = points[k].x;
						int y_1 = points[k].y;
						
						Line line = new Line(x_0, y_0, x_1, y_1);
						
						String toappend = String.valueOf(line.getLength()) + ":" + String.valueOf(x_0) + "," + String.valueOf(y_0) + ";" + String.valueOf(x_1) + "," + String.valueOf(y_1) + "-";
						//System.out.println(toappend);
						sb.append(toappend);
						
					}
				}
				
				String[] distances = extractDistances(sb);
				
				Arrays.sort(distances);
				
				int counter = 1;
				
				int a = 0; 
				int b = 1; 
				int c = 2;
				
				for(int i = 12; i < 24; i+=2) {
					
					/*Ablauf:
					- Pixel/Meter ausrechnen
					- Umrechnung a,b,c in Meter zu Pixel (in Abh�ngigkeit von Counter und eigene Klasse?!)
					- setTriangles mit den Werten aufrufen (Typ und H�he von ImagePlus in Pixel)*/
					
					String[] split_length = distances[i].split(":");
					
					double length = Double.parseDouble(split_length[0]);

					String[] split_xy = split_length[1].split(";");
					
					String[] split_xy0 = split_xy[0].split(",");
					String[] split_xy1 = split_xy[1].split(",");
					
					int x1 = Integer.parseInt(split_xy0[0]);
					int y1 = Integer.parseInt(split_xy0[1]);
					int x2 = Integer.parseInt(split_xy1[0]);
					int y2 = Integer.parseInt(split_xy1[1]);
					
					double Pixel_pro_Meter = length / getlength(project, counter, c);
					
					double d_a = Pixel_pro_Meter * getlength(project, counter, a);
					double d_b = Pixel_pro_Meter * getlength(project, counter, b);
					double d_c = Pixel_pro_Meter * getlength(project, counter, c);
					
					//System.out.println(Pixel_pro_Meter + "\n" + d_a + "\n" + d_b + "\n" + d_c);
					
					int type = 0;
					
					if(counter == 1 || counter == 4 || counter == 5) {
						type = 1;
					}
					if(counter == 3 || counter == 6) {
						type = 2;
					}
					if(counter == 2) {
						type = 3;
					}
					
					setTriangles(counter, height, d_a, d_b, d_c, x1, y1, x2, y2, type);
					
					counter++;
				}
				
				/*
				- Punkte sortieren
				- Punkte in PolygonRoi speichern
				- PolygonRoi anzeigen mit drawPixels()
				*/
				
				int[] orderedXPoints = reorderXY(xpoints);
				int[] orderedYPoints = reorderXY(ypoints);
				int amount_points = orderedXPoints.length;
				
				//imp2.setRoi(new PolygonRoi(orderedXPoints,orderedYPoints,amount_points,Roi.POLYGON));
				
				//imp2.setRoi(new PointRoi(orderedXPoints, orderedYPoints, amount_points));
				
				/*for(int i = 0; i < amount_points; i++) {
					xpoints_flaechen[i] = orderedXPoints[i];
					ypoints_flaechen[i] = orderedYPoints[i];
					point_counter++;
				}*/
				
				setRectangles(height, project);
				
				int[] pointsX = new int[points_up_counter+points_down_counter];
				int[] pointsY = new int[points_up_counter+points_down_counter];
				
				int[] xpoints_polygon = new int[4];
				int[] ypoints_polygon = new int[4];
				int polygon_counter = 0;
				int polygon_column = 0;
				int export_polygon = 1; //AKHWA I f�ngt bei 1 an, AKWHA II geht dann mit 65 weiter
				
				ImagePlus imp_export = imp2;
				ImagePlus[] imp_crop = new ImagePlus[ypoints_flaechen.length];
				
				String text = "";
				String filename = "";
				
				String export_pixelvalues = "";
				String filename_pixelvalues = "";
				
				imp2.setRoi(new PointRoi(xpoints_flaechen, ypoints_flaechen, ypoints_flaechen.length));
				IJ.run("Scale to Fit", "");
				
				for(int i = 0; i < ypoints_flaechen.length - 5/*i<15*/; i++) {
					//System.out.println("Punkt:" + i + "," + xpoints_flaechen[i] + "," + ypoints_flaechen[i]);
					System.out.println(xpoints_flaechen[i] + "," + ypoints_flaechen[i]);
					
					imp_crop[i] = new ImagePlus();
					imp_crop[i].setImage(imp2);
					
					/*PolygonRoi mit 4 Punkten:
						- x[i] und y[i], x[i+1] und y[i+1], x[i+5] und y[i+5], x[i+6] und y[i+6]
						- 4 mal und dann eins auslassen 
						*/
					
					polygon_counter++;
					if(polygon_counter < 5) {
						if(polygoncolumn(polygon_column)) {
							
							imp_crop[i].show();
							
							xpoints_polygon[0] = xpoints_flaechen[i];
							ypoints_polygon[0] = ypoints_flaechen[i];
							xpoints_polygon[1] = xpoints_flaechen[i+1];
							ypoints_polygon[1] = ypoints_flaechen[i+1];
							xpoints_polygon[2] = xpoints_flaechen[i+6];
							ypoints_polygon[2] = ypoints_flaechen[i+6];
							xpoints_polygon[3] = xpoints_flaechen[i+5];
							ypoints_polygon[3] = ypoints_flaechen[i+5];	
							
							double x1 = (double)xpoints_polygon[0];
							double y1 = (double)ypoints_polygon[0];
							double x2 = (double)xpoints_polygon[3];
							double y2 = (double)ypoints_polygon[3];
							double x3 = (double)xpoints_polygon[1];
							double y3 = (double)ypoints_polygon[1];
							double x4 = (double)xpoints_polygon[2];
							double y4 = (double)ypoints_polygon[2];
														
							double distance_scale_up = Abstand_PunktPunkt(x1, y1, x2, y2);
							double distance_scale_down = Abstand_PunktPunkt(x3, y3, x4, y4);
							double distance_scale_left = Abstand_PunktPunkt(x2, y2, x4, y4);
							double distance_scale_right = Abstand_PunktPunkt(x3, y3, x1, y1);
														
							double scale_CMPx_up = 600/distance_scale_up;
							double scale_CMPx_down = 600/distance_scale_down;
							double scale_CMPx_left = 1500/distance_scale_left;
							double scale_CMPx_right = 1500/distance_scale_right;
							
							scale_CMPx = (scale_CMPx_up + scale_CMPx_down + scale_CMPx_left + scale_CMPx_right)/4;
							
							System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
							
							System.out.println("Distance_scale_up: " + distance_scale_up + "\nDistance_scale_down: " + distance_scale_down + "\ndistance_scale_left: " + distance_scale_left + "\ndistance_scale_right: " + distance_scale_right);
							
							System.out.println("scale_CMPx_up: " + scale_CMPx_up + "\nscale_CMPx_down: " + scale_CMPx_down + "\nscale_CMPx_left: " + scale_CMPx_left + "\nscale_CMPx_right: " + scale_CMPx_right);
														
							Roi polygonroi = new PolygonRoi(xpoints_polygon,ypoints_polygon,ypoints_polygon.length,Roi.POLYGON);
							
							imp_crop[i].setRoi(polygonroi);
							
							IJ.run(imp_crop[i], "Crop", "");
							IJ.setBackgroundColor(0, 0, 0);
							IJ.run(imp_crop[i], "Clear Outside", "");
							
							Roi newmask = imp_crop[i].getRoi();
							
							String name = StartFileDirectory + "/Export/" + StartFileName + "_" + export_polygon;
							
							String export_name = name + ".tif";
							
							IJ.saveAs(imp_crop[i], "tiff", name);
							
							int crop_height = imp_crop[i].getHeight();
							int crop_width = imp_crop[i].getWidth();
							
							ByteProcessor bp_selection = createRoiMask(imp_crop[i]);
							
							byte[] selection = (byte[])bp_selection.getPixels();
							
							int invers = 0;
							
							for(int k = 0; k < selection.length; k++) {
								if(selection[k] == 0) {
									invers++;
								}
							}
							
							System.out.println("selection_length: " + selection.length);
							System.out.println("selection_invers: " + invers);
							
							ColorThresholderExtended thresher = new ColorThresholderExtended(); //Color Threshold Fenster �ffnen
							
							Integer[] input_int = new Integer[9];
							input_int[0] = minHue;
							input_int[1] = maxHue;
							input_int[2] = minSat;
							input_int[3] = maxSat;
							input_int[4] = minBri;
							input_int[5] = maxBri;
							input_int[6] = mode;
							input_int[7] = colorSpace;
							input_int[8] = method_int;
							
							Boolean[] input_bool = new Boolean[4];
							input_bool[0] = bandPassH;
							input_bool[1] = bandPassS;
							input_bool[2] = bandPassB;
							input_bool[3] = darkBackground;
							
							//thresher.setStringValue(method);
							thresher.setIntValues(input_int);
							thresher.setBoolValues(input_bool);
							
							InputDialog inputcolorthresher = new InputDialog("Input", "Please adjust Threshold", "Threshold", imp_crop[i]);
							inputcolorthresher.show();
							
							//color_string_value = thresher.getStringValue();
							color_int_values = thresher.getIntValues();
							color_bool_values = thresher.getBoolValues();
							
							//method = color_string_value;
							method = "DEFAULT";
							minHue = color_int_values[0];
							maxHue = color_int_values[1];
							minSat = color_int_values[2];
							maxSat = color_int_values[3];
							minBri = color_int_values[4];
							maxBri = color_int_values[5];
							mode = color_int_values[6];
							colorSpace = color_int_values[7];
							method_int = color_int_values[8];
							bandPassH = color_bool_values[0];
							bandPassS = color_bool_values[1];
							bandPassB = color_bool_values[2];
							darkBackground = color_bool_values[3];
							
							String added = color_int_values[0] + ", " + color_int_values[1] + ", " + color_bool_values[0] + ", " + color_int_values[2] + ", " + color_int_values[3] + ", " + color_bool_values[1] + ", " + color_int_values[4] + ", " + color_int_values[5] + ", " + color_bool_values[2] + ", " + color_int_values[8] + ", " + color_int_values[6] + ", " + color_int_values[7] + ", " + color_bool_values[3];
							
							System.out.println("Values: " + added);							
							
							PixelMask = thresher.getdrawfillMask();
							
							thresher.drawBinary(PixelMask, imp_crop[i]);
							
							thresher.close();
							
							String name_export = StartFileDirectory + "/Export/" + StartFileName + "_" + export_polygon + "_binary.tif";
							
							IJ.saveAs(imp_crop[i], "tiff", name_export);
							
							//Fl�che berechnen
														
							double real_area_complete = 0;
							DecimalFormat df = new DecimalFormat("#.#####");
							double measure_counter = 0;
							
							if(scale_CMPx != 0) {
								real_area_complete = (crop_width * scale_CMPx) * (crop_height * scale_CMPx);
							}
							
							for(int k = 0; k < PixelMask.length; k++){
								if (PixelMask[k]!=0){
									//fill
									measure_counter++;
								}
							}
							//measure_counter = thresholded Pixel
							double PixelFraction = (measure_counter * 100) / (PixelMask.length - invers);
							
							double real_area = real_area_complete-(invers*scale_CMPx*scale_CMPx);
							
							double RealFraction = (real_area * PixelFraction) / 100;
							
							System.out.println("PixelMask.length: " + PixelMask.length + "\nMeasure_Counter: " + measure_counter + "\nPixelFraction: " + PixelFraction + "\nArea: " + real_area + "\nInvers: " + invers);
							
							String pixel_aFraction_df = df.format(PixelFraction); 
							String real_Fraction_df = df.format(RealFraction);
							
							String real_Fraction_complete = real_Fraction_df + " cm�";
							
							if(RealFraction == 0) {
								real_Fraction_complete = "Konnte nicht ausgerechnet werden.";
							}
							
							text = "Prozentuale Fl\u00e4che: " + pixel_aFraction_df + " %" + "\nReale Fl\u00e4che: " + real_Fraction_complete;
							filename = StartFileName + "_" + export_polygon + "_Fl\u00e4chenexport" + ".txt";	
							
							Opener opener_topixel = new Opener();
							ImagePlus imp_a_pixelvalues = opener_topixel.openImage(export_name);
							
							if(imp_a_pixelvalues != null){
								String[] rgb_values = extractPixelValues(imp_a_pixelvalues, PixelMask);
								
								StringBuilder sb_pixel = new StringBuilder();
						
								for(int l = 0; l < rgb_values.length; l++){
									sb_pixel.append(rgb_values[l]);
								}
								export_pixelvalues = sb_pixel.toString();
								filename_pixelvalues = StartFileName + "_" + export_polygon + "_Einzelpixel_Export" + ".txt";
							}
							
							export_polygon++;
							
							imp_crop[i].close();
							
						}
						
				    } else {
						polygon_counter = 0;
						polygon_column++;
					}
					
					//Hier Text-Dateien speichern
					
					saveData(text, filename);
					saveData(export_pixelvalues, filename_pixelvalues);
					
				}
				
				//imp2.setRoi(new PointRoi(pointsX, pointsY, pointsY.length));
				//imp2.setRoi(new PointRoi(xpoints_flaechen, ypoints_flaechen, ypoints_flaechen.length));
				//IJ.run("Scale to Fit", "");
				
				//imp_export.show();
				
			}
			imp2.close();
			problem = false;
		}
		
		if(project == AKWHA_II) {
			
			InputDialog inputreferencepoints = new InputDialog("Input", "Please enter Reference-Points for AKWHA II Project\nPoints are movable\nDelete with ALT + Click on Point", "AKWHA", imp2); //�berpr�fen ob 12 Punkte eingegeben wurden! �ber anderen Input �ber "Points"
			inputreferencepoints.show();
			
			Point[] points;
			Roi rois;
			
			rois = imp2.getRoi();
			
			if( rois instanceof PointRoi ){
				points = rois.getContainedPoints();
				System.out.println("Length: " + points.length);
				
				StringBuilder sb = new StringBuilder();
				
				for(int i = 0; i < points.length; i++){
					for(int k = 0; k < points.length; k++) {
						
						int x_0 = points[i].x;
						int y_0 = points[i].y;
						
						int x_1 = points[k].x;
						int y_1 = points[k].y;
						
						Line line = new Line(x_0, y_0, x_1, y_1);
						
						String toappend = String.valueOf(line.getLength()) + ":" + String.valueOf(x_0) + "," + String.valueOf(y_0) + ";" + String.valueOf(x_1) + "," + String.valueOf(y_1) + "-";
						System.out.println(toappend);
						sb.append(toappend);
						
					}
				}
				
				String[] distances = extractDistances(sb);
				
				Arrays.sort(distances);
				
				int counter = 1;
				
				int a = 0; 
				int b = 1; 
				int c = 2;
				
				for(int i = 12; i < 24; i+=2) {
					
					/*Ablauf:
					- Pixel/Meter ausrechnen
					- Umrechnung a,b,c in Meter zu Pixel (in Abh�ngigkeit von Counter und eigene Klasse?!)
					- setTriangles mit den Werten aufrufen (Typ und H�he von ImagePlus in Pixel)*/
					
					String[] split_length = distances[i].split(":");
					
					double length = Double.parseDouble(split_length[0]);

					String[] split_xy = split_length[1].split(";");
					
					String[] split_xy0 = split_xy[0].split(",");
					String[] split_xy1 = split_xy[1].split(",");
					
					int x1 = Integer.parseInt(split_xy0[0]);
					int y1 = Integer.parseInt(split_xy0[1]);
					int x2 = Integer.parseInt(split_xy1[0]);
					int y2 = Integer.parseInt(split_xy1[1]);
					
					double Pixel_pro_Meter = length / getlength(project, counter, c);
					
					double d_a = Pixel_pro_Meter * getlength(project, counter, a);
					double d_b = Pixel_pro_Meter * getlength(project, counter, b);
					double d_c = Pixel_pro_Meter * getlength(project, counter, c);
					
					System.out.println(Pixel_pro_Meter + "\n" + d_a + "\n" + d_b + "\n" + d_c);
					
					int type = 0;
					
					if(counter == 1 || counter == 3 || counter == 5) {
						type = 1;
					}
					if(counter == 2 || counter == 6) {
						type = 2;
					}
					if(counter == 4) { //hier noch ein anderer Type n�tig?
						type = 4;
					}
					
					setTriangles(counter, height, d_a, d_b, d_c, x1, y1, x2, y2, type);
					
					counter++;
				}
				
				/*
				- Punkte sortieren
				- Punkte in PolygonRoi speichern
				- PolygonRoi anzeigen mit drawPixels()
				*/
				
				int[] orderedXPoints = reorderXY(xpoints);
				int[] orderedYPoints = reorderXY(ypoints);
				int amount_points = orderedXPoints.length;
				
				//Gefundenen Ecken anzeigen lassen:
				imp2.setRoi(new PointRoi(orderedXPoints, orderedYPoints, amount_points));
				
				setRectangles(height, project);
				
				int[] pointsX = new int[points_up_counter+points_down_counter];
				int[] pointsY = new int[points_up_counter+points_down_counter];
				
				int[] xpoints_polygon = new int[4];
				int[] ypoints_polygon = new int[4];
				int polygon_counter = 0;
				int polygon_column = 0;
				int export_polygon = 65; //AKHWA II f�ngt bei 65 an, geht nach AKWHA I weiter
				
				ImagePlus imp_export = imp2;
				ImagePlus[] imp_crop = new ImagePlus[ypoints_flaechen.length];
				
				String text = "";
				String filename = "";
				
				String export_pixelvalues = "";
				String filename_pixelvalues = "";
				
				//Gefundene Fl�chen anzeigen lassen:
				imp2.setRoi(new PointRoi(xpoints_flaechen, ypoints_flaechen, ypoints_flaechen.length));
				IJ.run("Scale to Fit", "");
				
				for(int i = 0; i < ypoints_flaechen.length - 5/*i<15*/; i++) {
					//System.out.println("Punkt:" + i + "," + xpoints_flaechen[i] + "," + ypoints_flaechen[i]);
					System.out.println(xpoints_flaechen[i] + "," + ypoints_flaechen[i]);
					
					imp_crop[i] = new ImagePlus();
					imp_crop[i].setImage(imp2);	
					
					/*PolygonRoi mit 4 Punkten:
						- x[i] und y[i], x[i+1] und y[i+1], x[i+5] und y[i+5], x[i+6] und y[i+6]
						- 4 mal und dann eins auslassen 
						*/
					
					polygon_counter++;
					if(polygon_counter < 5) {
						if(polygoncolumn(polygon_column)) {
							
							imp_crop[i].show();
							
							xpoints_polygon[0] = xpoints_flaechen[i];
							ypoints_polygon[0] = ypoints_flaechen[i];
							xpoints_polygon[1] = xpoints_flaechen[i+1];
							ypoints_polygon[1] = ypoints_flaechen[i+1];
							xpoints_polygon[2] = xpoints_flaechen[i+6];
							ypoints_polygon[2] = ypoints_flaechen[i+6];
							xpoints_polygon[3] = xpoints_flaechen[i+5];
							ypoints_polygon[3] = ypoints_flaechen[i+5];	
							
							double x1 = (double)xpoints_polygon[0];
							double y1 = (double)ypoints_polygon[0];
							double x2 = (double)xpoints_polygon[3];
							double y2 = (double)ypoints_polygon[3];
							double x3 = (double)xpoints_polygon[1];
							double y3 = (double)ypoints_polygon[1];
							double x4 = (double)xpoints_polygon[2];
							double y4 = (double)ypoints_polygon[2];
														
							double distance_scale_up = Abstand_PunktPunkt(x1, y1, x2, y2);
							double distance_scale_down = Abstand_PunktPunkt(x3, y3, x4, y4);
							double distance_scale_left = Abstand_PunktPunkt(x2, y2, x4, y4);
							double distance_scale_right = Abstand_PunktPunkt(x3, y3, x1, y1);
														
							double scale_CMPx_up = 600/distance_scale_up;
							double scale_CMPx_down = 600/distance_scale_down;
							double scale_CMPx_left = 1500/distance_scale_left;
							double scale_CMPx_right = 1500/distance_scale_right;
							
							scale_CMPx = (scale_CMPx_up + scale_CMPx_down + scale_CMPx_left + scale_CMPx_right)/4;
							
							System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
							
							System.out.println("Distance_scale_up: " + distance_scale_up + "\nDistance_scale_down: " + distance_scale_down + "\ndistance_scale_left: " + distance_scale_left + "\ndistance_scale_right: " + distance_scale_right);
							
							System.out.println("scale_CMPx_up: " + scale_CMPx_up + "\nscale_CMPx_down: " + scale_CMPx_down + "\nscale_CMPx_left: " + scale_CMPx_left + "\nscale_CMPx_right: " + scale_CMPx_right);
														
							Roi polygonroi = new PolygonRoi(xpoints_polygon,ypoints_polygon,ypoints_polygon.length,Roi.POLYGON);
							
							imp_crop[i].setRoi(polygonroi);
							
							IJ.run(imp_crop[i], "Crop", "");
							IJ.setBackgroundColor(0, 0, 0);
							IJ.run(imp_crop[i], "Clear Outside", "");
							
							Roi newmask = imp_crop[i].getRoi();
							
							String name = StartFileDirectory + "/Export/" + StartFileName + "_" + export_polygon;
							
							String export_name = name + ".tif";
							
							IJ.saveAs(imp_crop[i], "tiff", name);
							
							int crop_height = imp_crop[i].getHeight();
							int crop_width = imp_crop[i].getWidth();
							
							ByteProcessor bp_selection = createRoiMask(imp_crop[i]);
							
							byte[] selection = (byte[])bp_selection.getPixels();
							
							int invers = 0;
							
							for(int k = 0; k < selection.length; k++) {
								if(selection[k] == 0) {
									invers++;
								}
							}
							
							System.out.println("selection_length: " + selection.length);
							System.out.println("selection_invers: " + invers);
							
							ColorThresholderExtended thresher = new ColorThresholderExtended(); //Color Threshold Fenster �ffnen
							
							Integer[] input_int = new Integer[9];
							input_int[0] = minHue;
							input_int[1] = maxHue;
							input_int[2] = minSat;
							input_int[3] = maxSat;
							input_int[4] = minBri;
							input_int[5] = maxBri;
							input_int[6] = mode;
							input_int[7] = colorSpace;
							input_int[8] = method_int;
							
							Boolean[] input_bool = new Boolean[4];
							input_bool[0] = bandPassH;
							input_bool[1] = bandPassS;
							input_bool[2] = bandPassB;
							input_bool[3] = darkBackground;
							
							//thresher.setStringValue(method);
							thresher.setIntValues(input_int);
							thresher.setBoolValues(input_bool);
							
							InputDialog inputcolorthresher = new InputDialog("Input", "Please adjust Threshold", "Threshold", imp_crop[i]);
							inputcolorthresher.show();
							
							//color_string_value = thresher.getStringValue();
							color_int_values = thresher.getIntValues();
							color_bool_values = thresher.getBoolValues();
							
							//method = color_string_value;
							method = "DEFAULT";
							minHue = color_int_values[0];
							maxHue = color_int_values[1];
							minSat = color_int_values[2];
							maxSat = color_int_values[3];
							minBri = color_int_values[4];
							maxBri = color_int_values[5];
							mode = color_int_values[6];
							colorSpace = color_int_values[7];
							method_int = color_int_values[8];
							bandPassH = color_bool_values[0];
							bandPassS = color_bool_values[1];
							bandPassB = color_bool_values[2];
							darkBackground = color_bool_values[3];
							
							String added = color_int_values[0] + ", " + color_int_values[1] + ", " + color_bool_values[0] + ", " + color_int_values[2] + ", " + color_int_values[3] + ", " + color_bool_values[1] + ", " + color_int_values[4] + ", " + color_int_values[5] + ", " + color_bool_values[2] + ", " + color_int_values[8] + ", " + color_int_values[6] + ", " + color_int_values[7] + ", " + color_bool_values[3];
							
							System.out.println("Values: " + added);							
							
							PixelMask = thresher.getdrawfillMask();
							
							thresher.drawBinary(PixelMask, imp_crop[i]);
							
							thresher.close();
							
							String name_export = StartFileDirectory + "/Export/" + StartFileName + "_" + export_polygon + "_binary.tif";
							
							IJ.saveAs(imp_crop[i], "tiff", name_export);
							
							//Fl�che berechnen
														
							double real_area_complete = 0;
							DecimalFormat df = new DecimalFormat("#.#####");
							double measure_counter = 0;
							
							if(scale_CMPx != 0) {
								real_area_complete = (crop_width * scale_CMPx) * (crop_height * scale_CMPx);
							}
							
							for(int k = 0; k < PixelMask.length; k++){
								if (PixelMask[k]!=0){
									//fill
									measure_counter++;
								}
							}
							//measure_counter = thresholded Pixel
							double PixelFraction = (measure_counter * 100) / (PixelMask.length - invers);
							
							double real_area = real_area_complete-(invers*scale_CMPx*scale_CMPx);
							
							double RealFraction = (real_area * PixelFraction) / 100;
							
							System.out.println("PixelMask.length: " + PixelMask.length + "\nMeasure_Counter: " + measure_counter + "\nPixelFraction: " + PixelFraction + "\nArea: " + real_area + "\nInvers: " + invers);
							
							String pixel_aFraction_df = df.format(PixelFraction); 
							String real_Fraction_df = df.format(RealFraction);
							
							String real_Fraction_complete = real_Fraction_df + " cm�";
							
							if(RealFraction == 0) {
								real_Fraction_complete = "Konnte nicht ausgerechnet werden.";
							}
							
							text = "Prozentuale Fl\u00e4che: " + pixel_aFraction_df + " %" + "\nReale Fl\u00e4che: " + real_Fraction_complete;
							filename = StartFileName + "_" + export_polygon + "_Fl\u00e4chenexport" + ".txt";	
							
							Opener opener_topixel = new Opener();
							ImagePlus imp_a_pixelvalues = opener_topixel.openImage(export_name);
							
							if(imp_a_pixelvalues != null){
								String[] rgb_values = extractPixelValues(imp_a_pixelvalues, PixelMask);
								
								StringBuilder sb_pixel = new StringBuilder();
						
								for(int l = 0; l < rgb_values.length; l++){
									sb_pixel.append(rgb_values[l]);
								}
								export_pixelvalues = sb_pixel.toString();
								filename_pixelvalues = StartFileName + "_" + export_polygon + "_Einzelpixel_Export" + ".txt";
							}
							
							export_polygon++;
							
							imp_crop[i].close();
							
						}
						
				    } else {
						polygon_counter = 0;
						polygon_column++;
					}
					
					//Hier Text-Dateien speichern
					
					saveData(text, filename);
					saveData(export_pixelvalues, filename_pixelvalues);
					
				}
				
				//imp2.setRoi(new PointRoi(pointsX, pointsY, pointsY.length));
				//imp2.setRoi(new PointRoi(xpoints_flaechen, ypoints_flaechen, ypoints_flaechen.length));
				//IJ.run("Scale to Fit", "");
				
				//imp_export.show();
				
			}
			imp2.close();
			problem = false;
		
		}
	}
	
	public void setTriangles(int counter, int height, double a, double b, double c, int n_x1, int n_y1, int n_x2, int n_y2, int type) {
		/*
		Ablauf:
		- je nach Typ Koordinaten anpassen (3 und 2) 
		- Steigung der Geraden zwischen x1y1 und x2y2
			-> Steigung positiv, negativ oder 0
		- Winkel dieser Steigung
		- Winkel alpha im Punkt A
		- Winkel beta im Punkt B
		- in Abh�ngigkeit vom Typ Steigungen m_AC und m_BC berechnen
		- Y-Achsenschnittpunkt nA und nB berechnen
		- Schnittpunkt xSyS berechnen
		- je nach Typ yS anpassen in yS_real (3 und 2)
		- Punkte in Arrays speichern*/
		
		double x1 = 0;
		double x2 = 0;
		double y1 = 0;
		double y2 = 0;
		
		double m_temp = 0;
		double m;
		double m_Winkel;
		double alpha;
		double beta;
		
		double m_A;
		double m_B;
		double n_A;
		double n_B;
		
		double Sx;
		double Sy;
		
		double Winkel_A;
		double Winkel_B;
		
		double m_Winkel_Abs;
		
		double Steigungswinkel_A = 0;
		double Steigungswinkel_B = 0;
		
		if(type == 1) {
			//Typ 1
			x1 = n_x1;
			x2 = n_x2;
			y1 = n_y1;
			y2 = n_y2;
		} 
		if(type == 2) {
			//Typ 2
			x1 = n_x1;
			x2 = n_x2;
			y1 = height - n_y1;
			y2 = height - n_y2;
		}
		if(type == 3) {
			//Typ 3
			if(n_x1 == n_x2) {
				m_temp = 0;
			} else {
				m_temp = (n_y2-n_y1)/(n_x2-n_x1);
			}
			
			if(m_temp < 0) {
				x1 = n_x2;
				x2 = n_x1;
				y1 = height - n_y2;
				y2 = height - n_y1;
			}
			if(m_temp >= 0) {
				x1 = n_x1;
				x2 = n_x2;
				y1 = height - n_y1;
				y2 = height - n_y2;
			}
		}
		if(type == 4) {
			//Typ 4
			if(n_x1 == n_x2) {
				m_temp = 0;
			} else {
				m_temp = (n_y2-n_y1)/(n_x2-n_x1);
			}
			
			if(m_temp < 0) {
				x1 = n_x2;
				x2 = n_x1;
				y1 = height - n_y2;
				y2 = height - n_y1;
			}
			if(m_temp >= 0) {
				x1 = n_x1;
				x2 = n_x2;
				y1 = height - n_y1;
				y2 = height - n_y2;
			}
		}
		
		m = (y2-y1)/(x2-x1);
		
		m_Winkel = Math.toDegrees(Math.atan(m));
		
		alpha = Math.toDegrees(Math.acos((b*b+c*c-a*a)/(2*b*c)));
		
		beta = Math.toDegrees(Math.acos((a*a+c*c-b*b)/(2*a*c)));
		
		//System.out.println("\n" + counter);
	
		System.out.println(counter + ": Steigung: " + m + "\nWinkel: " + m_Winkel + "\nalpha: " + alpha + "\nbeta: " + beta);
		System.out.println(x1 + "," + y1 + "," + x2 + "," + y2);
		
		//Steigungen m_AC und m_BC
		
		if(type == 1) {
			if(m > 0) { //Steigung (m) positiv (Typ 1 oder 2)
				Winkel_A = alpha;
				Winkel_B = 180 - beta;
				
				Steigungswinkel_A = 180-(180-m_Winkel-Winkel_A);
				Steigungswinkel_B = 180-(180-m_Winkel-Winkel_B);
			}
			if(m < 0) { //Steigung (m) negativ (Typ 1 oder 2)
				Winkel_A = 180 - alpha;
				Winkel_B = beta;
				
				m_Winkel_Abs = Math.abs(m_Winkel);
				
				Steigungswinkel_A = 180-m_Winkel_Abs-Winkel_A;
				Steigungswinkel_B = 180-m_Winkel_Abs-Winkel_B;
			}
			if(m == 0) { //Steigung (m) 0 (Typ 1 oder 2)
				Steigungswinkel_A = alpha;
				Steigungswinkel_B = 180 - beta;
			}
		}
		if(type == 2) {
			if(m > 0) { //Steigung (m) positiv (Typ 1 oder 2)
				Winkel_A = alpha;
				Winkel_B = 180 - beta;
				
				Steigungswinkel_A = 180-(180-m_Winkel-Winkel_A);
				Steigungswinkel_B = 180-(180-m_Winkel-Winkel_B);
			}
			if(m < 0) { //Steigung (m) negativ (Typ 1 oder 2)
				Winkel_A = 180 - alpha;
				Winkel_B = beta;
				
				m_Winkel_Abs = Math.abs(m_Winkel);
				
				Steigungswinkel_A = 180-m_Winkel_Abs-Winkel_A;
				Steigungswinkel_B = 180-m_Winkel_Abs-Winkel_B;
			}
			if(m == 0) { //Steigung (m) 0 (Typ 1 oder 2)
				Steigungswinkel_A = alpha;
				Steigungswinkel_B = 180 - beta;
			}
		}
		if(type == 3) {
			if(m > 0) { //Steigung (m) positiv (Typ 3)
				Winkel_A = alpha;
				Winkel_B = beta;
				
				m_Winkel_Abs = Math.abs(m_Winkel);
				
				Steigungswinkel_A = 180-(180-m_Winkel_Abs)-Winkel_A;
				Steigungswinkel_B = 180-(180-m_Winkel_Abs-Winkel_B);
			}
			if(m < 0) { //Steigung (m) negativ (Typ 3)
				Winkel_A = alpha;
				Winkel_B = beta;
				
				m_Winkel_Abs = Math.abs(m_Winkel);
				
				Steigungswinkel_A = 180-m_Winkel_Abs-Winkel_A;
				Steigungswinkel_B = 180-(180-Winkel_B-(180-m_Winkel_Abs));
			}
			if(m == 0) { //Steigung (m) 0 (Typ 1 oder 2)
				Steigungswinkel_A = alpha;
				Steigungswinkel_B = 180 - beta;
			}
		}
		if(type == 4) {
			if(m > 0) { //Steigung (m) positiv (Typ 4)
				Winkel_A = alpha;
				Winkel_B = beta;
				
				m_Winkel_Abs = Math.abs(m_Winkel);
				
				Steigungswinkel_A = 180-(180-m_Winkel_Abs-Winkel_B);
				Steigungswinkel_B = 180-(180-m_Winkel_Abs)-Winkel_A;
			}
			if(m < 0) { //Steigung (m) negativ (Typ 4)
				Winkel_A = beta;
				Winkel_B = alpha;
				
				m_Winkel_Abs = Math.abs(m_Winkel);
				
				Steigungswinkel_A = 180-(m_Winkel_Abs-Winkel_A);
				Steigungswinkel_B = 180-m_Winkel_Abs-Winkel_B;
			}
			if(m == 0) { //Steigung (m) 0
				Steigungswinkel_A = alpha;
				Steigungswinkel_B = 180 - beta;
			}
		}
		
		m_A = Math.tan(Math.toRadians(Steigungswinkel_A));
		m_B = Math.tan(Math.toRadians(Steigungswinkel_B));
		
		n_A = y1 - m_A*x1;
		n_B = y2 - m_B*x2;
		
		System.out.println("Steigungswinkel_A: " + Steigungswinkel_A + "\nSteigungswinkel_B: " + Steigungswinkel_B);
		System.out.println("Steigung AC: " + m_A + "\nSteigung BC: " + m_B);
		System.out.println("y-Schnitt AC: " + n_A + "\ny-Schnitt BC: " + n_B);
		
		Sx = Schnittpunkt_X(n_A, n_B, m_A, m_B);
		
		if(type == 1) {
			//Typ 1
			Sy = Schnittpunkt_Y(n_A, n_B, m_A, m_B);
		} else {
			//Typ 2 und 3
			double d_height = (double)height;
			Sy = d_height - Schnittpunkt_Y(n_A, n_B, m_A, m_B);
		}
		
		xpoints[counter-1] = (int)Sx;
		ypoints[counter-1] = (int)Sy;
		
		System.out.println("Sx: " + Sx + "\nSy: " + Sy + "\n");
		
	}	
	
	public void setRectangles(int height, int project) {
		if(project == AKWHA_I) {
			/*
			Ablauf:
			- Steigung und Steigungswinkel
			- L�nge der Geraden
			- Abst�nde der Versuchsparzellen umrechnen in Pixel
				- Gerade zwischen 1 und 5 
					Punkte nach x sortieren und in points_1_5
				- Gerade zwischen 2 und 3
					Punkte nach x sortieren und in points_2_3
				- Gerade zwischen 1 und 2
					Punkte nach y sortieren und in points_1_2
				- Gerade zwischen 3 und 5
					Punkte nach y sortieren und in points_3_5
				- Gerade zwischen 4 und 5
					Punkte nach x sortieren und in points_4_5
				- Gerade zwischen 3 und 6
					Punkte nach x sortieren und in points_3_6
				- Gerade zwischen 4 und 6
					Punkte nach y sortieren und in points_4_6
			*/	
			
			double x1 = 0;
			double x2 = 0;
			double y1 = 0;
			double y2 = 0;
			
			double m = 0;
			double m_Winkel;
			
			double distance;
			double dist_temp = 0;
			double x_temp = 0;
			double y_temp = 0;
			
			//1-5
			points_up[points_up_counter] = new Point();
			points_up[points_up_counter].x = xpoints[0];
			points_up[points_up_counter].y = ypoints[0];
			points_up_counter++;
			
			x1 = xpoints[0];
			y1 = (double)height - ypoints[0];
			x2 = xpoints[4];
			y2 = (double)height - ypoints[4];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("1-5:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_right.length; i++) {
				
				dist_temp = distances_right[i] * distance / distances_right[11];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_up[points_up_counter] = new Point();
				points_up[points_up_counter].x = (int)x_temp;
				points_up[points_up_counter].y = (int)y_temp;
				points_up_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
				
			}
				
			//2-3
			
			points_down[points_down_counter] = new Point();
			points_down[points_down_counter].x = xpoints[1];
			points_down[points_down_counter].y = ypoints[1];
			points_down_counter++;
			
			x1 = xpoints[1];
			y1 = (double)height - ypoints[1];
			x2 = xpoints[2];
			y2 = (double)height - ypoints[2];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("2-3:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_right.length; i++) {
				
				dist_temp = distances_right[i] * distance / distances_right[11];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_down[points_down_counter] = new Point();
				points_down[points_down_counter].x = (int)x_temp;
				points_down[points_down_counter].y = (int)y_temp;
				points_down_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//5-4
			
			x1 = xpoints[4];
			y1 = (double)height - ypoints[4];
			x2 = xpoints[3];
			y2 = (double)height - ypoints[3];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("5-4:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_left.length; i++) {
				
				dist_temp = distances_left[i] * distance / distances_left[10];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_up[points_up_counter] = new Point();
				points_up[points_up_counter].x = (int)x_temp;
				points_up[points_up_counter].y = (int)y_temp;
				points_up_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//3-6
			
			x1 = xpoints[2];
			y1 = (double)height - ypoints[2];
			x2 = xpoints[5];
			y2 = (double)height - ypoints[5];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("3-6:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_left.length; i++) {
				
				dist_temp = distances_left[i] * distance / distances_left[10];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_down[points_down_counter] = new Point();
				points_down[points_down_counter].x = (int)x_temp;
				points_down[points_down_counter].y = (int)y_temp;
				points_down_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//6-4
			
			x1 = xpoints[5];
			y1 = (double)height - ypoints[5];
			x2 = xpoints[3];
			y2 = (double)height - ypoints[3];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("6-4:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_y.length; i++) {
				
				dist_temp = distances_y[i] * distance / distances_y[3];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				if(x1 < x2) {
					x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 > x2) {
					x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 == x2) {
					///???
				}
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//3-5
			
			x1 = xpoints[2];
			y1 = (double)height - ypoints[2];
			x2 = xpoints[4];
			y2 = (double)height - ypoints[4];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("3-5:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_y.length; i++) {
				
				dist_temp = distances_y[i] * distance / distances_y[3];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				if(x1 < x2) {
					x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 > x2) {
					x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 == x2) {
					///???
				} 
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//2-1
			
			x1 = xpoints[1];
			y1 = (double)height - ypoints[1];
			x2 = xpoints[0];
			y2 = (double)height - ypoints[0];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("2-1:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_y.length; i++) {
				
				dist_temp = distances_y[i] * distance / distances_y[3];
				
				//System.out.println("Distance_Temp: " + dist_temp);
				
				if(x1 < x2) {
					x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 > x2) {
					x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 == x2) {
					///???
				}
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//System.out.println("Points.x: " + points_up[0].x + "\nPoints.y: " + points_up[0].y);
			for(int k = 0; k < points_down_counter; k++) {
				Achsen(height, points_up[k], points_down[k], k);
				//Up nach Down von rechts oben nach links unten, wegen der Zahlen
			}
		}
		if(project == AKWHA_II) {
			/*
			Ablauf:
			- Steigung und Steigungswinkel
			- L�nge der Geraden
			- Abst�nde der Versuchsparzellen umrechnen in Pixel
				- Gerade zwischen 5 und 1 
					Punkte nach x sortieren und in points_5_1
				- Gerade zwischen 6 und 2
					Punkte nach x sortieren und in points_6_2
				- Gerade zwischen 5 und 6
					Punkte nach y sortieren und in points_5_6
				- Gerade zwischen 2 und 1
					Punkte nach y sortieren und in points_2_1
				- Gerade zwischen 3 und 1
					Punkte nach x sortieren und in points_4_5
				- Gerade zwischen 2 und 4
					Punkte nach x sortieren und in points_2_4
				- Gerade zwischen 3 und 4
					Punkte nach y sortieren und in points_3_4
			*/	
			
			double x1 = 0;
			double x2 = 0;
			double y1 = 0;
			double y2 = 0;
			
			double m = 0;
			double m_Winkel;
			
			double distance;
			double dist_temp = 0;
			double x_temp = 0;
			double y_temp = 0;
			
			//5-1
			points_up[points_up_counter] = new Point();
			points_up[points_up_counter].x = xpoints[4];
			points_up[points_up_counter].y = ypoints[4];
			points_up_counter++;
			
			x1 = xpoints[4];
			y1 = (double)height - ypoints[4];
			x2 = xpoints[0];
			y2 = (double)height - ypoints[0];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			System.out.println("5-1:");
			System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			System.out.println("Winkel: " + m_Winkel);
			System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_right_II.length; i++) {
				
				dist_temp = distances_right_II[i] * distance / distances_right_II[10];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_up[points_up_counter] = new Point();
				points_up[points_up_counter].x = (int)x_temp;
				points_up[points_up_counter].y = (int)y_temp;
				points_up_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
				
			}
				
			//6-2
			
			points_down[points_down_counter] = new Point();
			points_down[points_down_counter].x = xpoints[5];
			points_down[points_down_counter].y = ypoints[5];
			points_down_counter++;
			
			x1 = xpoints[5];
			y1 = (double)height - ypoints[5];
			x2 = xpoints[1];
			y2 = (double)height - ypoints[1];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("2-3:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_right_II.length; i++) {
				
				dist_temp = distances_right_II[i] * distance / distances_right_II[10];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_down[points_down_counter] = new Point();
				points_down[points_down_counter].x = (int)x_temp;
				points_down[points_down_counter].y = (int)y_temp;
				points_down_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//1-3
			
			x1 = xpoints[0];
			y1 = (double)height - ypoints[0];
			x2 = xpoints[2];
			y2 = (double)height - ypoints[2];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("5-4:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_left_II.length; i++) {
				
				dist_temp = distances_left_II[i] * distance / distances_left_II[11];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_up[points_up_counter] = new Point();
				points_up[points_up_counter].x = (int)x_temp;
				points_up[points_up_counter].y = (int)y_temp;
				points_up_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//2-4
			
			x1 = xpoints[1];
			y1 = (double)height - ypoints[1];
			x2 = xpoints[3];
			y2 = (double)height - ypoints[3];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("3-6:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_left_II.length; i++) {
				
				dist_temp = distances_left_II[i] * distance / distances_left_II[11];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				points_down[points_down_counter] = new Point();
				points_down[points_down_counter].x = (int)x_temp;
				points_down[points_down_counter].y = (int)y_temp;
				points_down_counter++;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//4-3
			
			x1 = xpoints[3];
			y1 = (double)height - ypoints[3];
			x2 = xpoints[2];
			y2 = (double)height - ypoints[2];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("6-4:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_y.length; i++) {
				
				dist_temp = distances_y[i] * distance / distances_y[3];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				if(x1 < x2) {
					x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 > x2) {
					x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 == x2) {
					///???
				}
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//2-1
			
			x1 = xpoints[1];
			y1 = (double)height - ypoints[1];
			x2 = xpoints[0];
			y2 = (double)height - ypoints[0];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("3-5:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_y.length; i++) {
				
				dist_temp = distances_y[i] * distance / distances_y[3];
				
				//System.out.println("Distance_Temp: " + dist_temp);
		
				if(x1 < x2) {
					x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 > x2) {
					x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 == x2) {
					///???
				} 
				
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//6-5
			
			x1 = xpoints[5];
			y1 = (double)height - ypoints[5];
			x2 = xpoints[4];
			y2 = (double)height - ypoints[4];
			
			if(x1 == x2) {
				m = 0;
			} else {
				m = Steigung(x1, y1, x2, y2);
			}
			
			//System.out.println("2-1:");
			//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
			
			m_Winkel = Math.toDegrees(Math.atan(m));
			
			distance = Abstand_PunktPunkt(x1, y1, x2, y2);
			
			//System.out.println("Winkel: " + m_Winkel);
			//System.out.println("Distance: " + distance);
			
			//Abst�nde berechnen
			
			for(int i = 0; i < distances_y.length; i++) {
				
				dist_temp = distances_y[i] * distance / distances_y[3];
				
				//System.out.println("Distance_Temp: " + dist_temp);
				
				if(x1 < x2) {
					x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 > x2) {
					x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
					y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
				}
				if(x1 == x2) {
					///???
				}
				//xpoints_flaechen[point_counter] = (int)x_temp;
				//ypoints_flaechen[point_counter] = (int)y_temp;
				
				//System.out.println("x_temp: " + x_temp);
				//System.out.println("y_temp: " + y_temp);
				
				//point_counter++;
			}
			
			//System.out.println("Points.x: " + points_up[0].x + "\nPoints.y: " + points_up[0].y);
			for(int k = 0; k < points_down_counter; k++) {
				Achsen(height, points_up[k], points_down[k], k);
				//Up nach Down von rechts oben nach links unten, wegen der Zahlen
			}
		}
	}
	
	public void Achsen(int height, Point up, Point down, int counter) {
		
		double x1 = 0;
		double x2 = 0;
		double y1 = 0;
		double y2 = 0;
		
		double m = 0;
		double m_Winkel;
		
		double distance;
		double dist_temp = 0;
		double x_temp = 0;
		double y_temp = 0;
		
		xpoints_flaechen[point_counter] = up.x;
		ypoints_flaechen[point_counter] = up.y;
		point_counter++;
		
		/*x1 = down.x;
		y1 = (double)height - down.y;
		x2 = up.x;
		y2 = (double)height - up.y;*/
		
		x1 = up.x;
		y1 = (double)height - up.y;
		x2 = down.x;
		y2 = (double)height - down.y;
		
		/*if(x1 == x2) {
			m = 0;
		} else {
			m = Steigung(x1, y1, x2, y2);
		}*/
		
		if(x1 == x2) {
			x1 = x1 + 1;
		}
		
		m = Steigung(x1, y1, x2, y2);
		
		//System.out.println(counter + ":");
		//System.out.println("Punkte: " + x1 + "," + y1 + "," + x2 + "," + y2);
		
		m_Winkel = Math.toDegrees(Math.atan(m));
		
		distance = Abstand_PunktPunkt(x1, y1, x2, y2);
		
		//System.out.println("Winkel: " + m_Winkel);
		//System.out.println("Distance: " + distance);
		
		//Abst�nde berechnen
		
		for(int i = 0; i < distances_y.length - 1; i++) {
			
			dist_temp = distances_y[i] * distance / distances_y[3];
			
			//System.out.println("Distance_Temp: " + dist_temp);
	
			if(x1 < x2) {
				x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
			}
			if(x1 > x2) {
				x_temp = x1 - Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				y_temp = (double)height - (y1 - Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
			}
			if(x1 == x2) { //??? Stimmt das so bereits?
				//x_temp = x1 + Math.cos(Math.toRadians(m_Winkel)) * dist_temp;
				//y_temp = (double)height - (y1 + Math.sin(Math.toRadians(m_Winkel)) * dist_temp);
			}
			
			xpoints_flaechen[point_counter] = (int)x_temp;
			ypoints_flaechen[point_counter] = (int)y_temp;
			
			//System.out.println("x_temp: " + x_temp);
			//System.out.println("y_temp: " + y_temp);
			
			point_counter++;
		}
		xpoints_flaechen[point_counter] = down.x;
		ypoints_flaechen[point_counter] = down.y;
		point_counter++;
	}
	
	double Steigung(double x1, double y1, double x2, double y2) {
		
		double value = (y2-y1)/(x2-x1);
		
		return value;
	}
	
	double Schnittpunkt_X(double n1, double n2, double m1, double m2) {
		
		double value = (n1-n2)/(m2-m1);
		
		return value;
	}
	
	double Schnittpunkt_Y(double n1, double n2, double m1, double m2) {
		
		double value = ((m2*n1)-(m1*n2))/(m2-m1);	
		
		return value;
	}
	
	double Abstand_PunktPunkt(double x1, double y1, double x2, double y2) {
		
		double dx = x2 - x1;
		double dy = y2 - y1;
		
		double value = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2));
		
		return value;
	}
	
	double getlength(int project, int number, int site) {
		
		double value = 0;
		
		if(project == AKWHA_I) {
		
			String[] splitarray = AKWHA_I_lengths[number-1].split(";");
			
			value = Double.parseDouble(splitarray[site]);
		
		}
		
		if(project == AKWHA_II) {
			
			String[] splitarray = AKWHA_II_lengths[number-1].split(";");
			
			value = Double.parseDouble(splitarray[site]);
		
		}
		
		return value;
	}
	
	boolean polygoncolumn(int column) {
		
		boolean value = true;
		
		if(column == 2 || column == 5 || column == 8 || column == 11 || column == 14 || column == 17 || column == 20) {
			value = false;
		}
		
		return value;
		
	}
	
	int[] reorderXY(int[] reorderArray) {
		int[] newArray = new int[reorderArray.length];
		
		newArray[0] = reorderArray[0];
		newArray[1] = reorderArray[1];
		newArray[2] = reorderArray[2];
		newArray[3] = reorderArray[5];
		newArray[4] = reorderArray[3];
		newArray[5] = reorderArray[4];
		
		return newArray;
		
	}
		
	String[] extractDistances(StringBuilder sb){
		
		String complete_array = sb.toString();
		
		String splitarray[]= complete_array.split("-");
		
		String[] distances = new String[splitarray.length];
		
		for(int i = 0; i < splitarray.length; i++) {
			
			String splitarray_value[]= splitarray[i].split(":");
			double value = Double.parseDouble(splitarray_value[0]);
			String actual_value = "";
			
			if(value <= 9){
				actual_value = "000" + String.valueOf(value);
			}
			if(value > 9 && value <= 99){
				actual_value = "00" + String.valueOf(value);
			}
			if(value > 99 && value <= 999){
				actual_value = "0" + String.valueOf(value);
			}
			
			distances[i] = actual_value + ":" + splitarray_value[1];
		}
		
		return distances;
	}
	
	public void getScale(ImagePlus imp) {
		
		IJ.setTool("line");
		
		InputDialog input = new InputDialog("Set the Scale", "Please draw Line on known Length\nLine and Points are movable", "Line", imp);
		input.show();	
		
		Roi roi;
		
		roi = imp.getRoi();
		double length = 0;
		double angle = 0;
		
		if(roi.isLine()){
			Line line = (Line)roi;
			length = roi.getLength();
			angle = roi.getAngle(line.x1, line.y1, line.x2, line.y2);
		}
		
		double reference = 0;
		
		while(reference == 0 || reference == 0 || reference == 0) {
			reference = getScaleReference();
		}
		
		scale_inCM = 10;
		
		scale_PxCM = length/reference;
		scale_CMPx = reference/length;
		
		System.out.println("Pixel/cm: " + scale_PxCM + "\ncm/Pixel: " + scale_CMPx);
		
	}
	
	private boolean showDialog() {
		// display dialog , return false if cancelled or on error.
		GenericDialog dlg = new GenericDialog("Harris Corner Detector", IJ.getInstance());
		float def_alpha = HarrisCornerDetector.DEFAULT_ALPHA;
		dlg.addNumericField("Alpha (default: "+def_alpha+")", alpha, 3);
		int def_threshold = HarrisCornerDetector.DEFAULT_THRESHOLD;
		dlg.addNumericField("Threshold (default: "+def_threshold+")", threshold, 0);
		dlg.addNumericField("Max. points (0 = show all)", nmax, 0);
		dlg.showDialog();
		if(dlg.wasCanceled())
			return false;
		if(dlg.invalidNumber()) {
			IJ.showMessage("Error", "Invalid input number");
			return false;
		}
		alpha = (float) dlg.getNextNumber();
		threshold = (int) dlg.getNextNumber();
		nmax = (int) dlg.getNextNumber();
		return true;
	}
		
	private boolean showInfo(String title, String message) {
		// display dialog , return false if cancelled or on error.
		GenericDialog dlg = new GenericDialog(title, IJ.getInstance());
		dlg.hideCancelButton();
		dlg.addMessage(message);
		
		dlg.showDialog();
		if(dlg.invalidNumber()) {
			IJ.showMessage("Error", "Invalid input number");
			return false;
		}
		
		return true;
	}
	
	String showChoice() {
		// display dialog , return false if cancelled or on error.
		int index = 0;
		String[] projektArray = {"Einzelnes Viereck Batch", "Oscar I", "AKHWA I", "AKHWA II", "EcoStack", "Mehrere Vierecke", "Einzelnes Viereck", "Referenzpunkte", "VORAN", "OSCAR"};
		String choice = "";
		
		GenericDialog dlg = new GenericDialog("Auswahl", IJ.getInstance());
		dlg.addMessage("Bitte Projekt ausw\u00e4hlen");
		dlg.addChoice( "Projekt", projektArray, projektArray[index] );
		
		dlg.showDialog();
		
		choice = dlg.getNextChoice();
		if(dlg.wasCanceled())
			return "";
		if(choice.equals("")) {
			IJ.showMessage("Error", "Invalid input number");
			return "";
		}
		
		return choice;
	}
	
	String enterName() {
		String Name = "";
		
		GenericDialog dlg = new GenericDialog("Eingabe", IJ.getInstance());
		dlg.addMessage("Bitte Name f�r Plot/Batch eingeben");
		dlg.addStringField( "Name", "", 2);
		
		dlg.showDialog();
		
		Name = (String)dlg.getNextString();
		
		if (dlg.wasCanceled()) {
			Name = "dlg.canceled";
			dlg.dispose();
		}
		
		return Name;
	}
	
	int showMehrereVierecke(){
		
		int choice = 0;
				
		GenericDialog dlg = new GenericDialog("Auswahl", IJ.getInstance());
		dlg.addMessage("Bitte Projekt ausw\u00e4hlen");
		dlg.addNumericField( "Anzahl Vierecke", 2, 0);
		
		dlg.showDialog();
		
		choice = (int)dlg.getNextNumber();
		
		if (dlg.wasCanceled()) {
			choice = -1;
			dlg.dispose();
		}
		
		return choice;
	}
	
	double getScaleReference(){
		
		double reference = 0;
		String[] einheitenarray = {"cm", "m"};
		
				
		GenericDialog dlg = new GenericDialog("Eingabe und Auswahl", IJ.getInstance());
		dlg.addMessage("Bitte L\u00e4nge eingeben und Einheit ausw\u00e4hlen");
		dlg.addStringField("L\u00e4nge","");
		dlg.addChoice( "Einheit", einheitenarray, einheitenarray[0] );
		
		dlg.showDialog();
		
		String reference_string = dlg.getNextString();		
		String einheit = dlg.getNextChoice();
		
		if(reference_string.contains(",")) {
			System.out.println("reference_String contains: " + reference_string);
			String replace_string = reference_string.replace(",",".").trim();
			reference_string = replace_string;
			System.out.println("reference_String contains after trim: " + reference_string);
		}
		
		System.out.println("reference_String Neu: " + reference_string);
		
		boolean convert = false;
		
		try {
			reference = Double.parseDouble(reference_string);
			convert = true;
		} catch(NumberFormatException ex) {
			  // handle exception
		}
		
		if(convert) {
			System.out.println("reference: " + reference);
			
			if(einheit.equals("cm") || einheit.equals("m")) {
				if(einheit.equals("m")){
					reference = reference * 100;
				}
			} else {
				reference = -2;
			}
		} else {
			// Parse nicht geklappt
			System.out.println("Parse: double nicht funktioniert");
			reference = -3;
		}
		
		if (dlg.wasCanceled()) {
			reference = -1;
			dlg.dispose();
		}
		
		return reference;
	}
	
	void saveData(String text, String filename) {
		//text = "";
		
		//Arrays.sort(coords_array);
		
		//for(int i = 0; i<good_coords_array.length; i++){
		//	text = text + good_coords_array[i] + "\n";
		//}
	
		String currentPath = getDirectory(imp);
		if(currentPath != null){
			String savePath = currentPath + "/Export";
			byte[] data = text.getBytes();
			try {
				File f = new File(savePath, filename);
					if (!f.exists()) {
					f.createNewFile();
					}
				FileOutputStream out = new FileOutputStream(f);
				out.write(data, 0, data.length);
				out.close();
			} catch (IOException e) {
				IJ.error("HarrisCornerDetector", ""+e);
			}
		}
	
	}
	
	void exportCropImages(String ImageToCrop, int CountImages, String Maske) {
		
		int blockcounter = 1;
		int counter = 0;
		int good_counter = 0;
		boolean startsaving = false;
		boolean two_control = false;
		int two_counter = 1;
		
		String entrys = "Saved Entries: \n";
		
		Arrays.sort(coords_array);
		
		String[] better_coords_array = new String[coords_array.length];
		
		for(int i=0; i<coords_array.length; i++){
			if(i > 0){
				//Vergleichen: Wenn array(i) und array(i-1) ungefähr gleich sind (innerhalb 5px) dann counter++
				String entry = coords_array[i];
				String oldentry = coords_array[i-1];
				
				String entrysplitarray[]= entry.split("_");
				String oldentrysplitarray[]= oldentry.split("_");
				
				String entry_x = entrysplitarray[0];
				String oldentry_x = oldentrysplitarray[0];
				
				
				int x = Integer.parseInt(entry_x);
				int old_x = Integer.parseInt(oldentry_x);
				
				int diff = x - old_x;
				
				/*if(diff >= 0 && diff < 5){
					blockcounter++;
				}*/
				
				//entrys = entrys + String.valueOf(blockcounter) + ": " + entry + "\n";
				
				if(startsaving){
					better_coords_array[good_counter] = entry;
					//System.out.println(entry);
					entrys = entrys + entry + "\n";
					good_counter++;
					counter++;
					if(counter == 16){
						counter = 0;
						startsaving = false;
						two_counter++; //
					}
				} else {
					if(diff >= 0 && diff < 5){
						blockcounter++;
					} else {
						if(blockcounter == 2){
							if(!two_control){
								two_control = true;
							}
							blockcounter = 1;
						}
						if(two_counter == 4){
							two_control = false;
							two_counter = 1;
						}
						if(!two_control && blockcounter == 5){
						blockcounter = 1;
						}
					}
					if(two_control && blockcounter == 5){
						startsaving = true;
						blockcounter = 1;
						
					}
					
				}
				
			}
		}
		
		good_coords_array = RemoveNullArray(better_coords_array);
		
		clean_coords_array = CleanArray(good_coords_array);
		
		//saveData(String.valueOf(good_coords_array.length), "coordsArray.txt");
		
		int imagecounter = 0;
		
		String[] correct_numbers = {"04", "03", "02", "01", "08", "07", "06", "05", "12", "11", "10", "09", "16", "15", "14", "13", "20", "19", "18", "17", "24", "23", "22", "21", "28", "27", "26", "25", "32", "31", "30", "29", "36", "35", "34", "33", "40", "39", "38", "37", "44", "43", "42", "41", "48", "47", "46", "45"};
		
		exportImages = new String[4*12];
		exportCalc = new String[4*12];
		String export = "Export der Fl\u00e4chenberechnung: \n";
		String filename = "";
		
		Opener opener = new Opener();
		ImagePlus impToCrop = opener.openImage(ImageToCrop);
		
		for(int i=0; i<23; i+=2){
			for(int k=0; k<8; k+=2){
		//for(int i=0; i<5; i+=2){
		//	for(int k=6; k==0; k-=2){
				
				int calc = i*8+k;
				int bigcalc = calc + 1;
				String x1y1 = clean_coords_array[calc]; 
				String x2y1 = clean_coords_array[calc + 8];
				String x1y2 = clean_coords_array[bigcalc]; 
				String x2y2 = clean_coords_array[bigcalc + 8];
				
				String x1y1split[]= x1y1.split("_");
				String x2y1split[]= x2y1.split("_");
				String x1y2split[]= x1y2.split("_");
				String x2y2split[]= x2y2.split("_");
				
				String x1 = x1y1split[0];
				String x2 = x2y1split[0];
				String y1 = x1y1split[1];
				String y2 = x2y2split[1];
				
				int roi_x1 = Integer.parseInt(x1);
				int roi_x2 = Integer.parseInt(x2);
				int roi_y1 = Integer.parseInt(y1);
				int roi_y2 = Integer.parseInt(y2);
				
				int a = roi_x2 - roi_x1;
				int b = roi_y2 - roi_y1;
				
				Roi roi_imp = new Roi(roi_x1, roi_y1, a, b);
				
				impToCrop.setRoi(roi_imp);
				ImagePlus imp3 = impToCrop.crop();
				
				//String name = StartFileDirectory + "/Export/" + String.valueOf(CountImages) + "_" + Maske + "_" + String.valueOf(imagecounter);
				String name = StartFileDirectory + "/Export/" + Maske + "_" + correct_numbers[imagecounter];
				
				exportImages[imagecounter] = name + ".jpg";
				
				IJ.saveAs(imp3, "jpg", name);
				
				imagecounter++;
				
			}	
		}
		
		//for(int i = 0; i < imagecounter; i++){
			//open exported image and perform LAB conversion
			
		//}
		/*
		Opener opener = new Opener();
		ImagePlus impToCrop = opener.openImage(ImageToCrop);
		impToCrop.setRoi(roi_imp);
		ImagePlus imp3 = impToCrop.crop();
		*/
		
		for(int i=0; i<exportImages.length; i++){
			Opener opener_toconvert = new Opener();
			ImagePlus impToConvert = opener_toconvert.openImage(exportImages[i]);
			
			//System.out.println(exportImages[i]);
			
			type = impToConvert.getType();
			
			ImagePlus converted_imp = convertToLab(impToConvert);
			
			converted_imp.show();
			
			System.out.println(String.valueOf(converted_imp.getStackSize()));
			
			imp_a = convertStackToImages(converted_imp);
			
			if(imp_a != null){
				
				imp_a.show();
				//IJ.run(imp_a, "Make Binary", "");
				ImageProcessor ip_binary = imp_a.getProcessor();
				ip_binary.setAutoThreshold(AutoThresholder.Method.Shanbhag, false, ImageProcessor.BLACK_AND_WHITE_LUT);
				ip_binary.autoThreshold(); 
				
				ImagePlus imagenew = new ImagePlus();
				imagenew.setProcessor(ip_binary);
				imp_a.close();
				imagenew.show();
				
				ImageStatistics stats = ImageStatistics.getStatistics(ip_binary, ImageStatistics.AREA_FRACTION, null);

				double aFraction = stats.areaFraction;
				
				double area = (aFraction * 27)/100;
				
				DecimalFormat df = new DecimalFormat("#.##");
				String aFraction_df = df.format(aFraction); 
				String area_df = df.format(area);
				
				String name = StartFileDirectory + "/Export/" + Maske + "_" + correct_numbers[i] + "_binary";
				
				IJ.saveAs(imagenew, "jpg", name);
				
				imagenew.close();
			
				System.out.println("Flaechenberechnung (" + correct_numbers[i] + "): " + String.valueOf(aFraction));
				//export = export + String.valueOf(CountImages) + "_" + Maske + "_" + correct_numbers[i] + ": " + area_df + "m\u00B2 (" + aFraction_df + "%)\n";
				exportCalc[i]= String.valueOf(CountImages) + "_" + Maske + "_" + correct_numbers[i] + ": " + area_df + "m\u00B2 (" + aFraction_df + "%)";
				filename = Maske + ".txt";
			}
		}
		
		Arrays.sort(exportCalc);
		
		for(int i=0; i<exportCalc.length; i++){
			export = export + exportCalc[i] + "\n";
		}
		
		saveData(export, filename);
		problem = false;
	}
	
	public void exportCropImagesevbatch(String FullName, String StartFileName, Roi rois, int index, String batchname) {
		
		int blockcounter = 1;
		int counter = 0;
		int good_counter = 0;
		boolean startsaving = false;
		boolean two_control = false;
		int two_counter = 1;
		int imagecounter = 0;
		int CountImages = 0;
		
		exportImages = new String[1];
		exportCalc = new String[1];
		String export = "Export der Fl\u00e4chenberechnung: \n";
		String export_pixelvalues = "";
		String filename = "";
		String filename_pixelvalues = "";
		
		Opener opener = new Opener();
		ImagePlus impToCrop = opener.openImage(FullName);
		
		impToCrop.setRoi(rois);
		
		//Rectangle rec = rois.getBounds();
		//System.out.println("x,y: " + rec.x + "," + rec.y);
		
		ImagePlus imp3 = impToCrop.crop();
		
		//String name = StartFileDirectory + "/Export/" + String.valueOf(CountImages) + "_" + Maske + "_" + String.valueOf(imagecounter);
		String name = StartFileDirectory + "/Export/" + StartFileName + "_" + batchname + "_" + String.valueOf(index) + "_" + "original";
		
		String export_name = name + ".tif";
		
		//IJ.saveAs(imp3, "jpg", name);
		
		IJ.saveAs(imp3, "tiff", name);
		
		Opener opener_toconvert = new Opener();
		ImagePlus imp_a = opener_toconvert.openImage(export_name);
		
		if(imp_a != null){
			
			imp_a.show();
			//IJ.run(imp_a, "Make Binary", "");
			
			Integer[] input_int = new Integer[9];
			input_int[0] = minHue;
			input_int[1] = maxHue;
			input_int[2] = minSat;
			input_int[3] = maxSat;
			input_int[4] = minBri;
			input_int[5] = maxBri;
			input_int[6] = mode;
			input_int[7] = colorSpace;
			input_int[8] = method_int;
			
			Boolean[] input_bool = new Boolean[4];
			input_bool[0] = bandPassH;
			input_bool[1] = bandPassS;
			input_bool[2] = bandPassB;
			input_bool[3] = darkBackground;
			
			try {	            
                Thread.sleep(200);
	        }
	        catch (Exception e) {
	            System.out.println(e);
	        }
			
			ColorThresholderExtended thresher = new ColorThresholderExtended(); //Color Threshold Fenster öffnen
			//thresher.setStringValue(method);
			thresher.setIntValues(input_int);
			thresher.setBoolValues(input_bool);
			
			thresher.updateAfterSetting(imp_a);
			
			if(index == 0) {
			
				InputDialog inputcolorthresher = new InputDialog("Input", "Please adjust Threshold", "Threshold", imp_a);
				inputcolorthresher.show();
				
				//color_string_value = thresher.getStringValue();
				color_int_values = thresher.getIntValues();
				color_bool_values = thresher.getBoolValues();
				
				//method = color_string_value;
				method = "DEFAULT";
				minHue = color_int_values[0];
				maxHue = color_int_values[1];
				minSat = color_int_values[2];
				maxSat = color_int_values[3];
				minBri = color_int_values[4];
				maxBri = color_int_values[5];
				mode = color_int_values[6];
				colorSpace = color_int_values[7];
				method_int = color_int_values[8];
				bandPassH = color_bool_values[0];
				bandPassS = color_bool_values[1];
				bandPassB = color_bool_values[2];
				darkBackground = color_bool_values[3];
				
			}	
			
			System.out.println("Active Windows: " + WindowManager.getWindowCount());
			
			//color_string_value = thresher.getStringValue();
			color_int_values = thresher.getIntValues();
			color_bool_values = thresher.getBoolValues();
			
			String added = color_int_values[0] + ", " + color_int_values[1] + ", " + color_bool_values[0] + ", " + color_int_values[2] + ", " + color_int_values[3] + ", " + color_bool_values[1] + ", " + color_int_values[4] + ", " + color_int_values[5] + ", " + color_bool_values[2] + ", " + color_int_values[8] + ", " + color_int_values[6] + ", " + color_int_values[7] + ", " + color_bool_values[3];
			
			System.out.println("Values: " + added);
			
			try {	            
                Thread.sleep(200);
	        }
	        catch (Exception e) {
	            System.out.println(e);
	        }
			
			//Hier bei Bedarf stattdessen Alterselection einf�gen
			PixelMask = thresher.getdrawfillMask();
			
			thresher.drawBinary(PixelMask, imp_a);
			
			thresher.close();
			
			String name_export = StartFileDirectory + "/Export/" + StartFileName + "_" + batchname + "_" + String.valueOf(index) + "_binary.tif";
			
			IJ.saveAs(imp_a, "tiff", name_export);
			
			imp_a.close();
			
			if(PixelMask != null) {
			
				Opener opener_tomeasure = new Opener();
				ImagePlus imp_m = opener_tomeasure.openImage(name_export);
				
				if(imp_m != null){
					ImageProcessor ip_binary = imp_m.getProcessor();
				
					ImageStatistics stats = ImageStatistics.getStatistics(ip_binary, ImageStatistics.AREA_FRACTION, null);
					
					int width = ip_binary.getWidth();
					int height = ip_binary.getHeight();
					
					double real_area = 0;
					
					if(scale_CMPx != 0) {
						real_area = (width * scale_CMPx) * (height * scale_CMPx);
					}
					
					double aFraction = stats.areaFraction;
					double greenFraction = 100-aFraction;
					//double area = (aFraction * 36)/100;
					
					DecimalFormat df = new DecimalFormat("#.#####");
					String aFraction_df = df.format(greenFraction); 
					
					double measure_counter = 0;
					
					for(int i = 0; i < PixelMask.length; i++){
						if (PixelMask[i]!=0){
							//fill
							measure_counter++;
						}
					}
					//Prozent Abdeckung der thresholded Pixel
					double PixelFraction = (measure_counter * 100) / PixelMask.length;
					
					double RealFraction = (real_area * PixelFraction) / 100;
					
					System.out.println("PixelMask.length: " + PixelMask.length + "\nMeasure_Counter: " + measure_counter + "\nPixelFraction: " + PixelFraction + "\nArea: " + real_area);
					
					String pixel_aFraction_df = df.format(PixelFraction); 
					String real_Fraction_df = df.format(RealFraction);
					
					String real_Fraction_complete = real_Fraction_df + " cm�";
					
					if(RealFraction == 0) {
						real_Fraction_complete = "Konnte nicht ausgerechnet werden.";
					}
					
					//String area_df = df.format(area);
					//System.out.println("Flaechenberechnung (" + String.valueOf(i) + "): " + String.valueOf(aFraction));
					//export = export + String.valueOf(CountImages) + "_" + Maske + "_" + correct_numbers[i] + ": " + area_df + "m\u00B2 (" + aFraction_df + "%)\n";
					//exportCalc[0]= "Fl\u00e4che: " + aFraction_df + "%" + "\nFl\u00e4che mit Schleife: " + pixel_aFraction_df + "%";
					exportCalc[0]= "Prozentuale Fl\u00e4che: " + pixel_aFraction_df + " %" + "\nReale Fl\u00e4che: " + real_Fraction_complete;
					filename = StartFileName + "_" + batchname + "_" + String.valueOf(index) + "_Fl\u00e4chenexport" + ".txt";		
					
					summary_batch = summary_batch + "\n" + batchname + "|" + StartFileName + "|" + real_Fraction_df + "|" + pixel_aFraction_df;
				}
				
				Opener opener_topixel = new Opener();
				ImagePlus imp_a_pixelvalues = opener_topixel.openImage(export_name);
				
				if(imp_a_pixelvalues != null){
					String[] rgb_values = extractPixelValues(imp_a_pixelvalues, PixelMask);
					
					StringBuilder sb = new StringBuilder();
			
					for(int i = 0; i < rgb_values.length; i++){
						sb.append(rgb_values[i]);
					}
					export_pixelvalues = sb.toString();
					filename_pixelvalues = StartFileName + "_" + batchname + "_" + String.valueOf(index) + "_Einzelpixel_Export" + ".txt";
				} else {
					summary_batch = summary_batch + "\n" + batchname + "|" + StartFileName + "|0|0";
				}
			}
		}
		
		if(PixelMask != null) {
			Arrays.sort(exportCalc);
			
			for(int i=0; i<exportCalc.length; i++){
				export = export + exportCalc[0] + "\n";
			}
			
			saveData(export, filename);
			saveData(export_pixelvalues, filename_pixelvalues);
			
			problem = false;
		}
		
	}
	
	public void exportCropImagesEinzelViereck(String FullName, String StartFileName, Roi rois, String Index) {
		
		int blockcounter = 1;
		int counter = 0;
		int good_counter = 0;
		boolean startsaving = false;
		boolean two_control = false;
		int two_counter = 1;
		int imagecounter = 0;
		int CountImages = 0;
		
		exportImages = new String[1];
		exportCalc = new String[1];
		String export = "Export der Fl\u00e4chenberechnung: \n";
		String export_pixelvalues = "";
		String filename = "";
		String filename_pixelvalues = "";
		
		Opener opener = new Opener();
		ImagePlus impToCrop = opener.openImage(FullName);
		
		impToCrop.setRoi(rois);
		
		//Rectangle rec = rois.getBounds();
		//System.out.println("x,y: " + rec.x + "," + rec.y);
		
		ImagePlus imp3 = impToCrop.crop();
		
		//String name = StartFileDirectory + "/Export/" + String.valueOf(CountImages) + "_" + Maske + "_" + String.valueOf(imagecounter);
		String name = StartFileDirectory + "/Export/" + StartFileName + "_" + Index + "_" + "original";
		
		String export_name = name + ".tif";
		
		//IJ.saveAs(imp3, "jpg", name);
		
		IJ.saveAs(imp3, "tiff", name);
		
		Opener opener_toconvert = new Opener();
		ImagePlus imp_a = opener_toconvert.openImage(export_name);
		
		if(imp_a != null){
			
			imp_a.show();
			//IJ.run(imp_a, "Make Binary", "");
			
			ColorThresholderExtended thresher = new ColorThresholderExtended(); //Color Threshold Fenster öffnen
		
			Integer[] input_int = new Integer[9];
			input_int[0] = minHue;
			input_int[1] = maxHue;
			input_int[2] = minSat;
			input_int[3] = maxSat;
			input_int[4] = minBri;
			input_int[5] = maxBri;
			input_int[6] = mode;
			input_int[7] = colorSpace;
			input_int[8] = method_int;
			
			Boolean[] input_bool = new Boolean[4];
			input_bool[0] = bandPassH;
			input_bool[1] = bandPassS;
			input_bool[2] = bandPassB;
			input_bool[3] = darkBackground;
			
			//thresher.setStringValue(method);
			thresher.setIntValues(input_int);
			thresher.setBoolValues(input_bool);
			
			InputDialog inputcolorthresher = new InputDialog("Input", "Please adjust Threshold", "Threshold", imp_a);
			inputcolorthresher.show();
			
			System.out.println("Active Windows: " + WindowManager.getWindowCount());
			
			//color_string_value = thresher.getStringValue();
			color_int_values = thresher.getIntValues();
			color_bool_values = thresher.getBoolValues();
			
			//method = color_string_value;
			method = "DEFAULT";
			minHue = color_int_values[0];
			maxHue = color_int_values[1];
			minSat = color_int_values[2];
			maxSat = color_int_values[3];
			minBri = color_int_values[4];
			maxBri = color_int_values[5];
			mode = color_int_values[6];
			colorSpace = color_int_values[7];
			method_int = color_int_values[8];
			bandPassH = color_bool_values[0];
			bandPassS = color_bool_values[1];
			bandPassB = color_bool_values[2];
			darkBackground = color_bool_values[3];
			
			String added = color_int_values[0] + ", " + color_int_values[1] + ", " + color_bool_values[0] + ", " + color_int_values[2] + ", " + color_int_values[3] + ", " + color_bool_values[1] + ", " + color_int_values[4] + ", " + color_int_values[5] + ", " + color_bool_values[2] + ", " + color_int_values[8] + ", " + color_int_values[6] + ", " + color_int_values[7] + ", " + color_bool_values[3];
			
			System.out.println("Values: " + added);
			
			int alterselection = dialolgAlterSelection();
			
			if(alterselection == 1) {
				//Ja Auswahl �ndern
				IJ.setTool("freehand");
				
				thresher.createSelection();
				
				InputDialog inputalterselection = new InputDialog("Input", "Please adjust Selection with ALT + Selection", "AlterSelection", imp_a);
				inputalterselection.show();
				
				//Roi roi_newselection = imp_a.getRoi();
				
				ByteProcessor bp_newselection = createRoiMask(imp_a);
				
				byte[] fillMask_newselection = (byte[])bp_newselection.getPixels();
				
				System.out.println("newselection_length: " + fillMask_newselection.length);
				
				PixelMask = fillMask_newselection;
				
			} else {
				//Nein Auswahl nicht �ndern
				PixelMask = thresher.getdrawfillMask();
			}
			
			thresher.drawBinary(PixelMask, imp_a);
			
			thresher.close();
			
			String name_export = StartFileDirectory + "/Export/" + StartFileName + "_" + Index + "_binary.tif";
			
			IJ.saveAs(imp_a, "tiff", name_export);
			
			imp_a.close();
			
			Opener opener_tomeasure = new Opener();
			ImagePlus imp_m = opener_tomeasure.openImage(name_export);
			
			if(imp_m != null){
				ImageProcessor ip_binary = imp_m.getProcessor();
			
				ImageStatistics stats = ImageStatistics.getStatistics(ip_binary, ImageStatistics.AREA_FRACTION, null);
				
				int width = ip_binary.getWidth();
				int height = ip_binary.getHeight();
				
				double real_area = 0;
				
				if(scale_CMPx != 0) {
					real_area = (width * scale_CMPx) * (height * scale_CMPx);
				}
				
				double aFraction = stats.areaFraction;
				double greenFraction = 100-aFraction;
				//double area = (aFraction * 36)/100;
				
				DecimalFormat df = new DecimalFormat("#.#####");
				String aFraction_df = df.format(greenFraction); 
				
				double measure_counter = 0;
				
				for(int i = 0; i < PixelMask.length; i++){
					if (PixelMask[i]!=0){
						//fill
						measure_counter++;
					}
				}
				//Prozent Abdeckung der thresholded Pixel
				double PixelFraction = (measure_counter * 100) / PixelMask.length;
				
				double RealFraction = (real_area * PixelFraction) / 100;
				
				System.out.println("PixelMask.length: " + PixelMask.length + "\nMeasure_Counter: " + measure_counter + "\nPixelFraction: " + PixelFraction + "\nArea: " + real_area);
				
				String pixel_aFraction_df = df.format(PixelFraction); 
				String real_Fraction_df = df.format(RealFraction);
				
				String real_Fraction_complete = real_Fraction_df + " cm�";
				
				if(RealFraction == 0) {
					real_Fraction_complete = "Konnte nicht ausgerechnet werden.";
				}
				
				//String area_df = df.format(area);
				//System.out.println("Flaechenberechnung (" + String.valueOf(i) + "): " + String.valueOf(aFraction));
				//export = export + String.valueOf(CountImages) + "_" + Maske + "_" + correct_numbers[i] + ": " + area_df + "m\u00B2 (" + aFraction_df + "%)\n";
				//exportCalc[0]= "Fl\u00e4che: " + aFraction_df + "%" + "\nFl\u00e4che mit Schleife: " + pixel_aFraction_df + "%";
				exportCalc[0]= "Prozentuale Fl\u00e4che: " + pixel_aFraction_df + " %" + "\nReale Fl\u00e4che: " + real_Fraction_complete;
				filename = StartFileName + "_" + Index + "_Fl\u00e4chenexport" + ".txt";				
			}
			
			Opener opener_topixel = new Opener();
			ImagePlus imp_a_pixelvalues = opener_topixel.openImage(export_name);
			
			if(imp_a_pixelvalues != null){
				String[] rgb_values = extractPixelValues(imp_a_pixelvalues, PixelMask);
				
				StringBuilder sb = new StringBuilder();
		
				for(int i = 0; i < rgb_values.length; i++){
					sb.append(rgb_values[i]);
				}
				export_pixelvalues = sb.toString();
				filename_pixelvalues = StartFileName + "_" + Index + "_Einzelpixel_Export" + ".txt";
			}
			
		}
		
		Arrays.sort(exportCalc);
		
		for(int i=0; i<exportCalc.length; i++){
			export = export + exportCalc[0] + "\n";
		}
		
		saveData(export, filename);
		saveData(export_pixelvalues, filename_pixelvalues);
		
		problem = false;
		
	}
	
	public ByteProcessor createRoiMask(ImagePlus imp) {
        Roi roi2 = imp.getRoi();
        Overlay overlay2 = getOverlay();
        if (roi2==null && overlay2==null)
            throw new IllegalArgumentException("ROI or overlay required");
        ByteProcessor mask = new ByteProcessor(imp.getWidth(),imp.getHeight());
        mask.setColor(255);
        if (roi2!=null)
            mask.fill(roi2);
        else if (overlay2!=null) {
            if (overlay2.size()==1 && (overlay2.get(0) instanceof ImageRoi)) {
                ImageRoi iRoi = (ImageRoi)overlay2.get(0);
                ImageProcessor ip = iRoi.getProcessor();
                if (ip.getWidth()!=mask.getWidth() || ip.getHeight()!=mask.getHeight())
                    return mask;
                for (int i=0; i<ip.getPixelCount(); i++) {
                    if (ip.get(i)!=0)
                        mask.set(i, 255);
                }
            } else {
                for (int i=0; i<overlay2.size(); i++)
                    mask.fill(overlay2.get(i));
            }
        }
        mask.setThreshold(255, 255, ImageProcessor.NO_LUT_UPDATE);
        return mask;
    }
	
	int dialolgAlterSelection(){
		
		int choice = 0;
				
		GenericDialog dlg = new GenericDialog("Change selection", IJ.getInstance());
		dlg.addMessage("Remove pixels from selection?");
		
		dlg.showDialog();
		
		choice = 1;
		
		if (dlg.wasCanceled()) {
			choice = -1;
			dlg.dispose();
		}
		
		return choice;
	}
	
	private boolean dialolgStackAction(String title, String message, boolean stackaction, ColorThresholderExtended thresher) {
		// display dialog , return false if cancelled or on error.
		NonBlockingGenericDialog dlg = new NonBlockingGenericDialog(title);
		dlg.hideCancelButton();
		dlg.addMessage(message);
		
		dlg.showDialog();
		if(dlg.invalidNumber()) {
			IJ.showMessage("Error", "Invalid input number");
			return false;
		}
		if(thresher.getStackAction()) {
			return true;
		}
		if(!stackaction) {
			return false;
		}
		
		return true;
	}
	
	String[] extractPixelValues(ImagePlus imp_pixel, byte[] PixelMask){
		
		ImageProcessor ip = imp_pixel.getProcessor();
		
		int width = ip.getWidth();
		int height = ip.getHeight();
		int numPixels = width*height;
		
		int[] pixels = (int[])ip.getPixels();
		int counter = 0;
		String[] rgb_values = new String[numPixels];
		
		for(int y = 0; y < height; y++){
			for(int x = 0; x < width; x++){
				if (PixelMask[counter]!=0){
					//fill
					int c = ip.getPixel(x,y);
					int r = (c&0xff0000)>>16;
					int g = (c&0xff00)>>8;
					int b = c&0xff;
					
					if(x == width-1){
						//rgb_values[counter] = "R:" + String.valueOf(r) + ",G:" + String.valueOf(g) + ",B:" + String.valueOf(b) + "\n";
						rgb_values[counter] = "R:" + r + ",G:" + g + ",B:" + b + "\n";
					} else {
						rgb_values[counter] = "R:" + r + ",G:" + g + ",B:" + b + "|";
					}
				}
				else {
					//keep
					if(x == width-1){
						//rgb_values[counter] = "R:" + String.valueOf(r) + ",G:" + String.valueOf(g) + ",B:" + String.valueOf(b) + "\n";
						rgb_values[counter] = "x\n";
					} else {
						rgb_values[counter]= "x|";
					}
					
					
				}
				counter++;
			}
		}
		//System.out.println("Counter: " + String.valueOf(counter));
		//System.out.println("numPixels: " + String.valueOf(numPixels));
		return rgb_values;
	}
	
	ImagePlus convertStackToImages(ImagePlus imp) { //StackEditor
		
		ImagePlus returnimage = null;
		
		if (!imp.lock())
			return null;
		ImageStack stack = imp.getStack();
		int size = stack.size();
		
		Calibration cal = imp.getCalibration();
		CompositeImage cimg = imp.isComposite()?(CompositeImage)imp:null;
		if (imp.getNChannels()!=imp.getStackSize()) cimg = null;
		Overlay overlay = imp.getOverlay();
		int lastImageID = 0;
		for (int i=1; i<=size; i++) {
			String label = stack.getShortSliceLabel(i);
			if (label!=null && (label.contains("/") || label.contains("\\") || label.contains(":")))
				label = null;
			String title = label!=null&&!label.equals("")?label:getTitle(imp, i);
			ImageProcessor ip = stack.getProcessor(i);
			if (cimg!=null) {
				LUT lut = cimg.getChannelLut(i);
				if (lut!=null) {
					ip.setColorModel(lut);
					ip.setMinAndMax(lut.min, lut.max);
				}
			}
			ImagePlus imp2 = new ImagePlus(title, ip);
			imp2.setCalibration(cal);
			String info = stack.getSliceLabel(i);
			if (info!=null && !info.equals(label))
				imp2.setProperty("Info", info);
			imp2.setIJMenuBar(i==size);
			if (overlay!=null) {
				Overlay overlay2 = new Overlay();
				for (int j=0; j<overlay.size(); j++) {
					Roi roi = overlay.get(j);
					if (roi.getPosition()==i) {
						roi.setPosition(0);
						overlay2.add((Roi)roi.clone());
					}
				}
				if (overlay2.size()>0)
					imp2.setOverlay(overlay2);
			}
			if (i==size)
				lastImageID = imp2.getID();
			//System.out.println(label);
			if(label.equals("a*")){
				//imp2.show();
				returnimage = imp2;
			}
			
		}
		imp.changes = false;
		ImageWindow win = imp.getWindow();
		if (win!=null)
			win.close();
		else if (Interpreter.isBatchMode())
			Interpreter.removeBatchModeImage(imp);
		imp.unlock();
		return returnimage;
	}
	
	String getTitle(ImagePlus imp, int n) {
		String digits = "00000000"+n;
		return getShortTitle(imp)+"-"+digits.substring(digits.length()-4,digits.length());
	}
	
	private String getShortTitle(ImagePlus imp) {
		String title = imp.getTitle();
		int index = title.indexOf(' ');
		if (index>-1)
			title = title.substring(0, index);
		index = title.lastIndexOf('.');
		if (index>0)
			title = title.substring(0, index);
		return title;
    }
	
	ImagePlus convertToLab(ImagePlus impToConvert) {
        if (type!=ImagePlus.COLOR_RGB)
            throw new IllegalArgumentException("Image must be RGB");
        ColorSpaceConverter converter = new ColorSpaceConverter();
        ImagePlus imp2 = converter.RGBToLab(impToConvert);
        Point loc = null;
        ImageWindow win = imp.getWindow();
        if (win!=null)
            loc = win.getLocation();
        ImageWindow.setNextLocation(loc);
        //imp2.show();
        imp.hide();
        imp2.copyAttributes(imp);
        imp.changes = false;
        imp.close();
		return imp2;
    }
	
	String[] RemoveNullArray(String[] removenullStringArray){
		
		List<String> list = new ArrayList<String>();

		for(String s : removenullStringArray) {
		   if(s != null && s.length() > 0) {
			  list.add(s);
		   }
		}
		removenullStringArray = list.toArray(new String[list.size()]);
		
		return removenullStringArray;
		
	}
	
	String[] CleanArray(String[] cleanStringArray){
		
		String[] result = new String[cleanStringArray.length];
		int counter = 0;
		double calc = 0;
		DecimalFormat df = new DecimalFormat("#");
		
		for(int i=0; i<cleanStringArray.length; i++){
			String entry = cleanStringArray[i];
			
			String entrysplitarray[]= entry.split("_");
			
			String entry_x = entrysplitarray[0];
			
			int x = Integer.parseInt(entry_x);
			
			counter++;
			
			calc = calc + x;
			
			String new_x = "";
			
			if(counter == 8){
				calc = calc/8;
				String value = df.format(calc);
				new_x = value;
				
				if(calc <= 9){
					new_x = "000" + value;
				}
				if(calc > 9 && calc <= 99){
					new_x = "00" + value;
				}
				if(calc > 99 && calc <= 999){
					new_x = "0" + value;
				}
				
				System.out.println(new_x);
				//result[i] = "bla";
				for(int k = 7; k>=0; k--){
					
					String splitentry = cleanStringArray[i-k];
					String splitentrysplitarray[]= splitentry.split("_");
					String entry_y = splitentrysplitarray[1];
					
					result[i-k] = new_x + "_" + entry_y;
					//result[i-k] = "bla";
				}
				counter = 0;
				calc = 0;
			}
			
		}
		Arrays.sort(result);
		return result;
		
	}
	
	String getDirectory(ImagePlus imp) {
		FileInfo fi = imp.getOriginalFileInfo();
		if (fi==null) return null;
		String dir = fi.openNextDir;
		if (dir==null) dir = fi.directory;
		return dir;
	}
	
	String getFileName(ImagePlus imp) {
		String name = imp.getOriginalFileInfo().fileName;
		return name;
	}
	
	String getFileDateandTime(ImagePlus imp) {
		ImageInfo info_image = new ImageInfo();
		String datetime = "";
		String returndatetime = "";
		
		String test_info = info_image.getImageInfo(imp);
		
		String subStr = "Date/Time Original:";
		
		int endposOfSubstr = test_info.indexOf(subStr) + subStr.length();
		if(endposOfSubstr > -1) {
			//Test auf korrektes Format und richtige Zeile in EXIFData:
			datetime = test_info.substring(endposOfSubstr, endposOfSubstr+20);
			if(!isLegalDate(datetime)) {
				datetime = "n/a";
			} else {				
				String[] split = datetime.split(" ");
				returndatetime = split[0].trim() + ":" + split[1];
			}
			
		} else {
		datetime = "n/a";	
		}
		
		return returndatetime;
	}
	
	boolean isLegalDate(String s) {
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
	    sdf.setLenient(false);
	    return sdf.parse(s, new ParsePosition(0)) != null;
	}
}